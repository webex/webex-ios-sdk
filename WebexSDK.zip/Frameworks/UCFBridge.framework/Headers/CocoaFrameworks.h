//
//  CocoaFrameworks.h
//  SparkMacDesktop
//
//  Created by Jimmy Coyne on 17/05/2018.
//  Copyright © 2018 Cisco Systems. All rights reserved.
//

#ifndef CocoaFrameworks_h
#define CocoaFrameworks_h

#import <Foundation/Foundation.h>
#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>

#define CCColor UIColor
#define CCFont  UIFont
#define CCImage UIImage
#define CCRect CGRect
#define CCSize CGSize
#define CCView  UIView

#else
#import <Cocoa/Cocoa.h>
#define CCColor NSColor
#define CCFont  NSFont
#define CCImage NSImage
#define CCSize NSSize
#define CCRect NSRect
#define CCView NSView
#endif





#endif /* CocoaFrameworks_h */
