// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHBreakoutSessionError_IMPORTED
#define CHBreakoutSessionError_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHBreakoutSessionError) {
    CHBreakoutSessionErrorJoinBreakoutSessionFailed,
    CHBreakoutSessionErrorJoinBreakoutSessionFailed_NotAllowed,
    CHBreakoutSessionErrorJoinBreakoutSessionFailed_UnsupportedDevice,
    CHBreakoutSessionErrorJoinBreakoutSessionFailed_CannotJoinLater,
    CHBreakoutSessionErrorReturnToMainSessionFailed,
    CHBreakoutSessionErrorReturnToMainSessionFailed_NotAllowed
};

#endif

