// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHVirtualBackgroundType_IMPORTED
#define CHVirtualBackgroundType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHVirtualBackgroundType) {
    CHVirtualBackgroundTypeNone,
    CHVirtualBackgroundTypeBlur,
    CHVirtualBackgroundTypeCustomized
};

#endif

