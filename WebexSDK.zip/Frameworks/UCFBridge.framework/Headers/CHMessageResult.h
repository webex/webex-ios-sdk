// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHMessageResult_IMPORTED
#define CHMessageResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHMessageResult) {
    CHMessageResultNoError,
    CHMessageResultUnknownError,
    CHMessageResultEmptyMessage,
    CHMessageResultMessageTooLong,
    CHMessageResultUnknownConversation,
    CHMessageResultNoFileData,
    CHMessageResultMentionedUserDoesNotExist,
    CHMessageResultParentMessageDeletedByAuthor,
    CHMessageResultParentMessageDeletedByModerator,
    CHMessageResultOneToOneParticipantRemovedFromCI,
    CHMessageResultInvalidUnicodeContentInMessage,
    CHMessageResultParentMessageDeletedByModeratorWhileEditing,
    CHMessageResultLinksAreDirty,
    CHMessageResultProvisionalSpaceConversionFailed,
    CHMessageResultServerError,
    CHMessageResultSpaceError,
    CHMessageResultInvalidFileData,
    CHMessageResultFileUploadFailed,
    CHMessageResultFileUploadBlockedForExternals,
    CHMessageResultOriginConversationNotAvailable,
    CHMessageResultOriginMessageNotAvailable,
    CHMessageResultUploadRestrictedOnNetwork
};

#endif

