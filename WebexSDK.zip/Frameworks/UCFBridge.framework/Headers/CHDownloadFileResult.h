// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHDownloadFileResult_IMPORTED
#define CHDownloadFileResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHDownloadFileResult) {
    CHDownloadFileResultNoError,
    CHDownloadFileResultUnknownError,
    CHDownloadFileResultInternalError,
    CHDownloadFileResultInvalidSpaceId,
    CHDownloadFileResultInvalidMessageID,
    CHDownloadFileResultInvalidContentIndex,
    CHDownloadFileResultInvalidDownloadPath,
    CHDownloadFileResultInvalidContent,
    CHDownloadFileResultBlocked,
    CHDownloadFileResultFileIsUnscannable
};

#endif

