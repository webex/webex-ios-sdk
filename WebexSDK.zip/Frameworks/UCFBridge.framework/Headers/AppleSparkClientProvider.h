#import <Foundation/Foundation.h>

#import "AppleMercuryNetworkConnectionDelegate.h"
#ifdef NEW_NETWORK_STACK
#import "NetworkStack/AppleHttpClientDelegate.h"
#endif

NS_ASSUME_NONNULL_BEGIN

@protocol AppleSparkClientProvider

@property (nonatomic, readonly) NSString *userAgent;
@property (nonatomic, readonly) NSString *oauthClientId;
@property (nonatomic, readonly) NSString *oauthClientSecret;
@property (nonatomic, readonly) NSString *oauthRedirectUri;

// Add more properties as needed to fulfill the necessary ISparkClient interface.
@property (nonatomic, readonly) NSString *bundleId;
@property (nonatomic, readonly) NSString *applicationVersion;
@property (nonatomic, readonly) NSString *operatingSystemVersion;
@property (nonatomic, readonly) NSString *operatingSystemLanguage;
@property (nonatomic, readonly) NSString *platformInfo;
@property (nonatomic, readonly) NSString *databasePath;
@property (nonatomic, readonly) NSString *wdmDeviceType;
@property (nonatomic, readonly) NSString *platformEncryptionIdentifier;
@property (nonatomic, readonly) NSString *appName;
@property (nonatomic, readonly) NSString *appType;
@property (nonatomic, readonly) NSString *oauthAdditionalScopes;
- (nullable NSString *)extraTelemetryMetaDataForMetricEventName:(NSString *)metricEventName;
@property (nonatomic, readonly) NSString *productName;
@property (nonatomic, readonly, getter=isDeveloperVersion) BOOL developerVersion;
@property (nonatomic, readonly, getter=isTablet) BOOL tablet;
@property (nonatomic, readonly) NSString *appleAccessGroupIdentifier;
- (nullable NSString *)additionalClientConfigForConfigName:(NSString *)configName;
- (void)createMercuryConnectionWithProvider:(id<AppleMercuryNetworkConnectionProviderProtocol>)provider;

@property (nonatomic, readonly) NSString *u2cUrl;

@property (nonatomic, readonly, getter=useNativeWebSocket) BOOL nativeWebSocket;
@property (nonatomic, readonly, getter=useNativeHttpClient) BOOL nativeHttpClient;

-(void)setMercuryPayloadLogging:(BOOL)enabled;

@property (nonatomic, readonly) unsigned int processorMaxFrequency;

@end

NS_ASSUME_NONNULL_END
