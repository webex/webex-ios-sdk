// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHMediaStreamQuality_IMPORTED
#define CHMediaStreamQuality_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHMediaStreamQuality) {
    CHMediaStreamQualityUndefined,
    CHMediaStreamQualityLD,
    CHMediaStreamQualitySD,
    CHMediaStreamQualityHD,
    CHMediaStreamQualityFHD
};

#endif

