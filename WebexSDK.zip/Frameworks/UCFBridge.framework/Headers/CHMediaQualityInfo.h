// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHMediaQualityInfo_IMPORTED
#define CHMediaQualityInfo_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHMediaQualityInfo) {
    CHMediaQualityInfoGood,
    CHMediaQualityInfoPoorUplink,
    CHMediaQualityInfoPoorDownlink,
    CHMediaQualityInfoNetworkLost,
    CHMediaQualityInfoDeviceLimitation,
    CHMediaQualityInfoHighCpuUsage
};

#endif

