// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHCreateSpaceMembershipResult_IMPORTED
#define CHCreateSpaceMembershipResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHCreateSpaceMembershipResult) {
    CHCreateSpaceMembershipResultNoError,
    CHCreateSpaceMembershipResultInvalidSpaceId,
    CHCreateSpaceMembershipResultNonModeratorCannotAddToModeratedSpace,
    CHCreateSpaceMembershipResultUserDoesntExistInOrg,
    CHCreateSpaceMembershipResultExternalUserNotAllowed,
    CHCreateSpaceMembershipResultCompanyPolicyPreventsMembershipCreation,
    CHCreateSpaceMembershipResultBotCannotBeAdded,
    CHCreateSpaceMembershipResultBotCannotBeAddedToDirectSpace,
    CHCreateSpaceMembershipResultTeamGuestMemberNotEntitled,
    CHCreateSpaceMembershipResultUserNotPartOfTeamOffice365,
    CHCreateSpaceMembershipResultUserNotPartOfOrganizationOffice365,
    CHCreateSpaceMembershipResultFailedToSetModerator,
    CHCreateSpaceMembershipResultFailedOperationDisallowedForCommercialGuest,
    CHCreateSpaceMembershipResultInternalError
};

#endif

