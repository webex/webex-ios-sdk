// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHListCalendarMeetingsResult_IMPORTED
#define CHListCalendarMeetingsResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHListCalendarMeetingsResult) {
    CHListCalendarMeetingsResultNoError,
    CHListCalendarMeetingsResultInternalError,
    CHListCalendarMeetingsResultCalendarServiceDisabled
};

#endif

