// DO NOT EDIT - Auto generated
// Generated with alltogether_objc_converter_header.j2
#import <Foundation/Foundation.h>
#ifdef __cplusplus
#ifndef APPLE_CONVERSION_FUNCTIONS_IMPORTED
#define APPLE_CONVERSION_FUNCTIONS_IMPORTED

#import "spark-client-framework/Services/IOmniusModels.h"
#import "spark-client-framework/Services/OmniusService/OmniusEnums.h"

#import "CHAccessTokenLoginResult.h"
#import "CHApplyVirtualBackgroundResult.h"
#import "CHBase64EncodeResult.h"
#import "CHBreakoutSessionError.h"
#import "CHCalendarMeetingEvent.h"
#import "CHCallAssociationType.h"
#import "CHCallDirection.h"
#import "CHCallMembershipState.h"
#import "CHCaptchaRefreshResult.h"
#import "CHCompositedVideoLayout.h"
#import "CHConversationSortType.h"
#import "CHConversationType.h"
#import "CHCreateSpaceMembershipResult.h"
#import "CHCreateTeamMembershipResult.h"
#import "CHCreateWebhookResult.h"
#import "CHDeleteMessageResult.h"
#import "CHDeleteSpaceResult.h"
#import "CHDeleteTeamMembershipResult.h"
#import "CHDeleteVirtualBackgroundResult.h"
#import "CHDeleteWebhookByIdResult.h"
#import "CHDownloadFileResult.h"
#import "CHDownloadThumbnailResult.h"
#import "CHFetchVirtualBackgroundResult.h"
#import "CHGetCalendarMeetingByIdResult.h"
#import "CHGetMembershipByIdResult.h"
#import "CHGetMessageResult.h"
#import "CHGetTeamMembershipResult.h"
#import "CHGetWebhookByIdResult.h"
#import "CHInviteeResponse.h"
#import "CHJoinBreakoutResult.h"
#import "CHJWTTokenResult.h"
#import "CHLetInResult.h"
#import "CHListCalendarMeetingsResult.h"
#import "CHListMembershipResult.h"
#import "CHListMembershipsReadStatusResult.h"
#import "CHListMessagesResult.h"
#import "CHListPersonsResult.h"
#import "CHListTeamMembershipResult.h"
#import "CHListWebhooksResult.h"
#import "CHMakeCallResult.h"
#import "CHMarkMessageReadResult.h"
#import "CHMediaQualityInfo.h"
#import "CHMediaStreamChangeEventType.h"
#import "CHMediaStreamQuality.h"
#import "CHMediaStreamType.h"
#import "CHMeetingLinkType.h"
#import "CHMeetingLockedErrorCodes.h"
#import "CHMeetingServiceType.h"
#import "CHMembershipDeleteResult.h"
#import "CHMembershipEvent.h"
#import "CHMembershipUpdateResult.h"
#import "CHMentionType.h"
#import "CHMessageEvent.h"
#import "CHMessageResult.h"
#import "CHNotificationCallType.h"
#import "CHOAuthResult.h"
#import "CHPersonCreateResult.h"
#import "CHPersonDeleteResult.h"
#import "CHPersonGetResult.h"
#import "CHPersonUpdateResult.h"
#import "CHPhoneServiceRegistrationFailureReason.h"
#import "CHPreviewVirtualBackgroundResult.h"
#import "CHResourceType.h"
#import "CHReturnToMainSessionResult.h"
#import "CHRole.h"
#import "CHServiceUrlType.h"
#import "CHSessionType.h"
#import "CHSetCompositedLayoutResult.h"
#import "CHSetRemoteVideoRenderModeResult.h"
#import "CHShareSourceType.h"
#import "CHSpaceEvent.h"
#import "CHTeamArchiveResult.h"
#import "CHTeamCreateResult.h"
#import "CHTeamGetResult.h"
#import "CHTeamListResult.h"
#import "CHTeamUpdateResult.h"
#import "CHTelemetry.h"
#import "CHUCBrowserLoginSSONavResult.h"
#import "CHUCLoginServerConnectionStatus.h"
#import "CHUCSSOFailureReason.h"
#import "CHUpdateSpaceTitleResult.h"
#import "CHUpdateTeamMembershipResult.h"
#import "CHUpdateWebhookByIdResult.h"
#import "CHUploadVirtualBackgroundResult.h"
#import "CHVideoFlashMode.h"
#import "CHVideoRenderMode.h"
#import "CHVideoStreamMode.h"
#import "CHVideoTorchMode.h"
#import "CHVirtualBackgroundType.h"
#import "CHWebexMeetingEntryPoint.h"

@class CHBreakout;
@class CHBreakoutSession;
@class CHCall;
@class CHCallHistoryRecord;
@class CHCallMembership;
@class CHCameraExposureDuration;
@class CHCameraExposureISO;
@class CHCameraExposureTargetBias;
@class CHCaptcha;
@class CHEmailAddress;
@class CHInvitee;
@class CHJoinMeetingParam;
@class CHKeyValues;
@class CHLocalFile;
@class CHMediaStream;
@class CHMediaStreamChangeEventInfo;
@class CHMeeting;
@class CHMeetingInfo;
@class CHMeetingJoinSuggestion;
@class CHMembership;
@class CHMembershipId;
@class CHMembershipReadStatus;
@class CHMention;
@class CHMessage;
@class CHMessageText;
@class CHPerson;
@class CHRemoteFile;
@class CHResource;
@class CHSpace;
@class CHSpaceApiErrorInfo;
@class CHSpaceMeetingInfo;
@class CHSpaceReadStatus;
@class CHTeam;
@class CHTeamMembership;
@class CHTeamMembershipId;
@class CHTranscription;
@class CHVideoFrameSize;
@class CHVirtualBackgroundItem;
@class CHVirtualBackgroundThumbnail;
@class CHWebhook;


NS_ASSUME_NONNULL_BEGIN

/*****************************************************************************/
#pragma mark - CHAccessTokenLoginResult <=> OmniusEnums::AccessTokenLoginResult
/*****************************************************************************/

CHAccessTokenLoginResult CHAccessTokenLoginResultFromCPP(const OmniusEnums::AccessTokenLoginResult& cppRepresentation);
OmniusEnums::AccessTokenLoginResult CHAccessTokenLoginResultToCPP(CHAccessTokenLoginResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHApplyVirtualBackgroundResult <=> OmniusEnums::ApplyVirtualBackgroundResult
/*****************************************************************************/

CHApplyVirtualBackgroundResult CHApplyVirtualBackgroundResultFromCPP(const OmniusEnums::ApplyVirtualBackgroundResult& cppRepresentation);
OmniusEnums::ApplyVirtualBackgroundResult CHApplyVirtualBackgroundResultToCPP(CHApplyVirtualBackgroundResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHBase64EncodeResult <=> OmniusEnums::Base64EncodeResult
/*****************************************************************************/

CHBase64EncodeResult CHBase64EncodeResultFromCPP(const OmniusEnums::Base64EncodeResult& cppRepresentation);
OmniusEnums::Base64EncodeResult CHBase64EncodeResultToCPP(CHBase64EncodeResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHBreakoutSessionError <=> OmniusEnums::BreakoutSessionError
/*****************************************************************************/

CHBreakoutSessionError CHBreakoutSessionErrorFromCPP(const OmniusEnums::BreakoutSessionError& cppRepresentation);
OmniusEnums::BreakoutSessionError CHBreakoutSessionErrorToCPP(CHBreakoutSessionError objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCalendarMeetingEvent <=> OmniusEnums::CalendarMeetingEvent
/*****************************************************************************/

CHCalendarMeetingEvent CHCalendarMeetingEventFromCPP(const OmniusEnums::CalendarMeetingEvent& cppRepresentation);
OmniusEnums::CalendarMeetingEvent CHCalendarMeetingEventToCPP(CHCalendarMeetingEvent objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCallAssociationType <=> OmniusEnums::CallAssociationType
/*****************************************************************************/

CHCallAssociationType CHCallAssociationTypeFromCPP(const OmniusEnums::CallAssociationType& cppRepresentation);
OmniusEnums::CallAssociationType CHCallAssociationTypeToCPP(CHCallAssociationType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCallDirection <=> OmniusEnums::CallDirection
/*****************************************************************************/

CHCallDirection CHCallDirectionFromCPP(const OmniusEnums::CallDirection& cppRepresentation);
OmniusEnums::CallDirection CHCallDirectionToCPP(CHCallDirection objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCallMembershipState <=> OmniusEnums::CallMembershipState
/*****************************************************************************/

CHCallMembershipState CHCallMembershipStateFromCPP(const OmniusEnums::CallMembershipState& cppRepresentation);
OmniusEnums::CallMembershipState CHCallMembershipStateToCPP(CHCallMembershipState objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCaptchaRefreshResult <=> OmniusEnums::CaptchaRefreshResult
/*****************************************************************************/

CHCaptchaRefreshResult CHCaptchaRefreshResultFromCPP(const OmniusEnums::CaptchaRefreshResult& cppRepresentation);
OmniusEnums::CaptchaRefreshResult CHCaptchaRefreshResultToCPP(CHCaptchaRefreshResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCompositedVideoLayout <=> OmniusEnums::CompositedVideoLayout
/*****************************************************************************/

CHCompositedVideoLayout CHCompositedVideoLayoutFromCPP(const OmniusEnums::CompositedVideoLayout& cppRepresentation);
OmniusEnums::CompositedVideoLayout CHCompositedVideoLayoutToCPP(CHCompositedVideoLayout objcRepresentation);

/*****************************************************************************/
#pragma mark - CHConversationSortType <=> OmniusEnums::ConversationSortType
/*****************************************************************************/

CHConversationSortType CHConversationSortTypeFromCPP(const OmniusEnums::ConversationSortType& cppRepresentation);
OmniusEnums::ConversationSortType CHConversationSortTypeToCPP(CHConversationSortType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHConversationType <=> OmniusEnums::ConversationType
/*****************************************************************************/

CHConversationType CHConversationTypeFromCPP(const OmniusEnums::ConversationType& cppRepresentation);
OmniusEnums::ConversationType CHConversationTypeToCPP(CHConversationType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCreateSpaceMembershipResult <=> OmniusEnums::CreateSpaceMembershipResult
/*****************************************************************************/

CHCreateSpaceMembershipResult CHCreateSpaceMembershipResultFromCPP(const OmniusEnums::CreateSpaceMembershipResult& cppRepresentation);
OmniusEnums::CreateSpaceMembershipResult CHCreateSpaceMembershipResultToCPP(CHCreateSpaceMembershipResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCreateTeamMembershipResult <=> OmniusEnums::CreateTeamMembershipResult
/*****************************************************************************/

CHCreateTeamMembershipResult CHCreateTeamMembershipResultFromCPP(const OmniusEnums::CreateTeamMembershipResult& cppRepresentation);
OmniusEnums::CreateTeamMembershipResult CHCreateTeamMembershipResultToCPP(CHCreateTeamMembershipResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCreateWebhookResult <=> OmniusEnums::CreateWebhookResult
/*****************************************************************************/

CHCreateWebhookResult CHCreateWebhookResultFromCPP(const OmniusEnums::CreateWebhookResult& cppRepresentation);
OmniusEnums::CreateWebhookResult CHCreateWebhookResultToCPP(CHCreateWebhookResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHDeleteMessageResult <=> OmniusEnums::DeleteMessageResult
/*****************************************************************************/

CHDeleteMessageResult CHDeleteMessageResultFromCPP(const OmniusEnums::DeleteMessageResult& cppRepresentation);
OmniusEnums::DeleteMessageResult CHDeleteMessageResultToCPP(CHDeleteMessageResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHDeleteSpaceResult <=> OmniusEnums::DeleteSpaceResult
/*****************************************************************************/

CHDeleteSpaceResult CHDeleteSpaceResultFromCPP(const OmniusEnums::DeleteSpaceResult& cppRepresentation);
OmniusEnums::DeleteSpaceResult CHDeleteSpaceResultToCPP(CHDeleteSpaceResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHDeleteTeamMembershipResult <=> OmniusEnums::DeleteTeamMembershipResult
/*****************************************************************************/

CHDeleteTeamMembershipResult CHDeleteTeamMembershipResultFromCPP(const OmniusEnums::DeleteTeamMembershipResult& cppRepresentation);
OmniusEnums::DeleteTeamMembershipResult CHDeleteTeamMembershipResultToCPP(CHDeleteTeamMembershipResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHDeleteVirtualBackgroundResult <=> OmniusEnums::DeleteVirtualBackgroundResult
/*****************************************************************************/

CHDeleteVirtualBackgroundResult CHDeleteVirtualBackgroundResultFromCPP(const OmniusEnums::DeleteVirtualBackgroundResult& cppRepresentation);
OmniusEnums::DeleteVirtualBackgroundResult CHDeleteVirtualBackgroundResultToCPP(CHDeleteVirtualBackgroundResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHDeleteWebhookByIdResult <=> OmniusEnums::DeleteWebhookByIdResult
/*****************************************************************************/

CHDeleteWebhookByIdResult CHDeleteWebhookByIdResultFromCPP(const OmniusEnums::DeleteWebhookByIdResult& cppRepresentation);
OmniusEnums::DeleteWebhookByIdResult CHDeleteWebhookByIdResultToCPP(CHDeleteWebhookByIdResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHDownloadFileResult <=> OmniusEnums::DownloadFileResult
/*****************************************************************************/

CHDownloadFileResult CHDownloadFileResultFromCPP(const OmniusEnums::DownloadFileResult& cppRepresentation);
OmniusEnums::DownloadFileResult CHDownloadFileResultToCPP(CHDownloadFileResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHDownloadThumbnailResult <=> OmniusEnums::DownloadThumbnailResult
/*****************************************************************************/

CHDownloadThumbnailResult CHDownloadThumbnailResultFromCPP(const OmniusEnums::DownloadThumbnailResult& cppRepresentation);
OmniusEnums::DownloadThumbnailResult CHDownloadThumbnailResultToCPP(CHDownloadThumbnailResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHFetchVirtualBackgroundResult <=> OmniusEnums::FetchVirtualBackgroundResult
/*****************************************************************************/

CHFetchVirtualBackgroundResult CHFetchVirtualBackgroundResultFromCPP(const OmniusEnums::FetchVirtualBackgroundResult& cppRepresentation);
OmniusEnums::FetchVirtualBackgroundResult CHFetchVirtualBackgroundResultToCPP(CHFetchVirtualBackgroundResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHGetCalendarMeetingByIdResult <=> OmniusEnums::GetCalendarMeetingByIdResult
/*****************************************************************************/

CHGetCalendarMeetingByIdResult CHGetCalendarMeetingByIdResultFromCPP(const OmniusEnums::GetCalendarMeetingByIdResult& cppRepresentation);
OmniusEnums::GetCalendarMeetingByIdResult CHGetCalendarMeetingByIdResultToCPP(CHGetCalendarMeetingByIdResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHGetMembershipByIdResult <=> OmniusEnums::GetMembershipByIdResult
/*****************************************************************************/

CHGetMembershipByIdResult CHGetMembershipByIdResultFromCPP(const OmniusEnums::GetMembershipByIdResult& cppRepresentation);
OmniusEnums::GetMembershipByIdResult CHGetMembershipByIdResultToCPP(CHGetMembershipByIdResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHGetMessageResult <=> OmniusEnums::GetMessageResult
/*****************************************************************************/

CHGetMessageResult CHGetMessageResultFromCPP(const OmniusEnums::GetMessageResult& cppRepresentation);
OmniusEnums::GetMessageResult CHGetMessageResultToCPP(CHGetMessageResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHGetTeamMembershipResult <=> OmniusEnums::GetTeamMembershipResult
/*****************************************************************************/

CHGetTeamMembershipResult CHGetTeamMembershipResultFromCPP(const OmniusEnums::GetTeamMembershipResult& cppRepresentation);
OmniusEnums::GetTeamMembershipResult CHGetTeamMembershipResultToCPP(CHGetTeamMembershipResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHGetWebhookByIdResult <=> OmniusEnums::GetWebhookByIdResult
/*****************************************************************************/

CHGetWebhookByIdResult CHGetWebhookByIdResultFromCPP(const OmniusEnums::GetWebhookByIdResult& cppRepresentation);
OmniusEnums::GetWebhookByIdResult CHGetWebhookByIdResultToCPP(CHGetWebhookByIdResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHInviteeResponse <=> OmniusEnums::InviteeResponse
/*****************************************************************************/

CHInviteeResponse CHInviteeResponseFromCPP(const OmniusEnums::InviteeResponse& cppRepresentation);
OmniusEnums::InviteeResponse CHInviteeResponseToCPP(CHInviteeResponse objcRepresentation);

/*****************************************************************************/
#pragma mark - CHJoinBreakoutResult <=> OmniusEnums::JoinBreakoutResult
/*****************************************************************************/

CHJoinBreakoutResult CHJoinBreakoutResultFromCPP(const OmniusEnums::JoinBreakoutResult& cppRepresentation);
OmniusEnums::JoinBreakoutResult CHJoinBreakoutResultToCPP(CHJoinBreakoutResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHJWTTokenResult <=> OmniusEnums::JWTTokenResult
/*****************************************************************************/

CHJWTTokenResult CHJWTTokenResultFromCPP(const OmniusEnums::JWTTokenResult& cppRepresentation);
OmniusEnums::JWTTokenResult CHJWTTokenResultToCPP(CHJWTTokenResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHLetInResult <=> OmniusEnums::LetInResult
/*****************************************************************************/

CHLetInResult CHLetInResultFromCPP(const OmniusEnums::LetInResult& cppRepresentation);
OmniusEnums::LetInResult CHLetInResultToCPP(CHLetInResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHListCalendarMeetingsResult <=> OmniusEnums::ListCalendarMeetingsResult
/*****************************************************************************/

CHListCalendarMeetingsResult CHListCalendarMeetingsResultFromCPP(const OmniusEnums::ListCalendarMeetingsResult& cppRepresentation);
OmniusEnums::ListCalendarMeetingsResult CHListCalendarMeetingsResultToCPP(CHListCalendarMeetingsResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHListMembershipResult <=> OmniusEnums::ListMembershipResult
/*****************************************************************************/

CHListMembershipResult CHListMembershipResultFromCPP(const OmniusEnums::ListMembershipResult& cppRepresentation);
OmniusEnums::ListMembershipResult CHListMembershipResultToCPP(CHListMembershipResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHListMembershipsReadStatusResult <=> OmniusEnums::ListMembershipsReadStatusResult
/*****************************************************************************/

CHListMembershipsReadStatusResult CHListMembershipsReadStatusResultFromCPP(const OmniusEnums::ListMembershipsReadStatusResult& cppRepresentation);
OmniusEnums::ListMembershipsReadStatusResult CHListMembershipsReadStatusResultToCPP(CHListMembershipsReadStatusResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHListMessagesResult <=> OmniusEnums::ListMessagesResult
/*****************************************************************************/

CHListMessagesResult CHListMessagesResultFromCPP(const OmniusEnums::ListMessagesResult& cppRepresentation);
OmniusEnums::ListMessagesResult CHListMessagesResultToCPP(CHListMessagesResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHListPersonsResult <=> OmniusEnums::ListPersonsResult
/*****************************************************************************/

CHListPersonsResult CHListPersonsResultFromCPP(const OmniusEnums::ListPersonsResult& cppRepresentation);
OmniusEnums::ListPersonsResult CHListPersonsResultToCPP(CHListPersonsResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHListTeamMembershipResult <=> OmniusEnums::ListTeamMembershipResult
/*****************************************************************************/

CHListTeamMembershipResult CHListTeamMembershipResultFromCPP(const OmniusEnums::ListTeamMembershipResult& cppRepresentation);
OmniusEnums::ListTeamMembershipResult CHListTeamMembershipResultToCPP(CHListTeamMembershipResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHListWebhooksResult <=> OmniusEnums::ListWebhooksResult
/*****************************************************************************/

CHListWebhooksResult CHListWebhooksResultFromCPP(const OmniusEnums::ListWebhooksResult& cppRepresentation);
OmniusEnums::ListWebhooksResult CHListWebhooksResultToCPP(CHListWebhooksResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMakeCallResult <=> OmniusEnums::MakeCallResult
/*****************************************************************************/

CHMakeCallResult CHMakeCallResultFromCPP(const OmniusEnums::MakeCallResult& cppRepresentation);
OmniusEnums::MakeCallResult CHMakeCallResultToCPP(CHMakeCallResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMarkMessageReadResult <=> OmniusEnums::MarkMessageReadResult
/*****************************************************************************/

CHMarkMessageReadResult CHMarkMessageReadResultFromCPP(const OmniusEnums::MarkMessageReadResult& cppRepresentation);
OmniusEnums::MarkMessageReadResult CHMarkMessageReadResultToCPP(CHMarkMessageReadResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMediaQualityInfo <=> OmniusEnums::MediaQualityInfo
/*****************************************************************************/

CHMediaQualityInfo CHMediaQualityInfoFromCPP(const OmniusEnums::MediaQualityInfo& cppRepresentation);
OmniusEnums::MediaQualityInfo CHMediaQualityInfoToCPP(CHMediaQualityInfo objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMediaStreamChangeEventType <=> OmniusEnums::MediaStreamChangeEventType
/*****************************************************************************/

CHMediaStreamChangeEventType CHMediaStreamChangeEventTypeFromCPP(const OmniusEnums::MediaStreamChangeEventType& cppRepresentation);
OmniusEnums::MediaStreamChangeEventType CHMediaStreamChangeEventTypeToCPP(CHMediaStreamChangeEventType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMediaStreamQuality <=> OmniusEnums::MediaStreamQuality
/*****************************************************************************/

CHMediaStreamQuality CHMediaStreamQualityFromCPP(const OmniusEnums::MediaStreamQuality& cppRepresentation);
OmniusEnums::MediaStreamQuality CHMediaStreamQualityToCPP(CHMediaStreamQuality objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMediaStreamType <=> OmniusEnums::MediaStreamType
/*****************************************************************************/

CHMediaStreamType CHMediaStreamTypeFromCPP(const OmniusEnums::MediaStreamType& cppRepresentation);
OmniusEnums::MediaStreamType CHMediaStreamTypeToCPP(CHMediaStreamType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMeetingLinkType <=> OmniusEnums::MeetingLinkType
/*****************************************************************************/

CHMeetingLinkType CHMeetingLinkTypeFromCPP(const OmniusEnums::MeetingLinkType& cppRepresentation);
OmniusEnums::MeetingLinkType CHMeetingLinkTypeToCPP(CHMeetingLinkType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMeetingLockedErrorCodes <=> OmniusEnums::MeetingLockedErrorCodes
/*****************************************************************************/

CHMeetingLockedErrorCodes CHMeetingLockedErrorCodesFromCPP(const OmniusEnums::MeetingLockedErrorCodes& cppRepresentation);
OmniusEnums::MeetingLockedErrorCodes CHMeetingLockedErrorCodesToCPP(CHMeetingLockedErrorCodes objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMeetingServiceType <=> OmniusEnums::MeetingServiceType
/*****************************************************************************/

CHMeetingServiceType CHMeetingServiceTypeFromCPP(const OmniusEnums::MeetingServiceType& cppRepresentation);
OmniusEnums::MeetingServiceType CHMeetingServiceTypeToCPP(CHMeetingServiceType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMembershipDeleteResult <=> OmniusEnums::MembershipDeleteResult
/*****************************************************************************/

CHMembershipDeleteResult CHMembershipDeleteResultFromCPP(const OmniusEnums::MembershipDeleteResult& cppRepresentation);
OmniusEnums::MembershipDeleteResult CHMembershipDeleteResultToCPP(CHMembershipDeleteResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMembershipEvent <=> OmniusEnums::MembershipEvent
/*****************************************************************************/

CHMembershipEvent CHMembershipEventFromCPP(const OmniusEnums::MembershipEvent& cppRepresentation);
OmniusEnums::MembershipEvent CHMembershipEventToCPP(CHMembershipEvent objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMembershipUpdateResult <=> OmniusEnums::MembershipUpdateResult
/*****************************************************************************/

CHMembershipUpdateResult CHMembershipUpdateResultFromCPP(const OmniusEnums::MembershipUpdateResult& cppRepresentation);
OmniusEnums::MembershipUpdateResult CHMembershipUpdateResultToCPP(CHMembershipUpdateResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMentionType <=> OmniusEnums::MentionType
/*****************************************************************************/

CHMentionType CHMentionTypeFromCPP(const OmniusEnums::MentionType& cppRepresentation);
OmniusEnums::MentionType CHMentionTypeToCPP(CHMentionType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMessageEvent <=> OmniusEnums::MessageEvent
/*****************************************************************************/

CHMessageEvent CHMessageEventFromCPP(const OmniusEnums::MessageEvent& cppRepresentation);
OmniusEnums::MessageEvent CHMessageEventToCPP(CHMessageEvent objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMessageResult <=> OmniusEnums::MessageResult
/*****************************************************************************/

CHMessageResult CHMessageResultFromCPP(const OmniusEnums::MessageResult& cppRepresentation);
OmniusEnums::MessageResult CHMessageResultToCPP(CHMessageResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHNotificationCallType <=> OmniusEnums::NotificationCallType
/*****************************************************************************/

CHNotificationCallType CHNotificationCallTypeFromCPP(const OmniusEnums::NotificationCallType& cppRepresentation);
OmniusEnums::NotificationCallType CHNotificationCallTypeToCPP(CHNotificationCallType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHOAuthResult <=> OmniusEnums::OAuthResult
/*****************************************************************************/

CHOAuthResult CHOAuthResultFromCPP(const OmniusEnums::OAuthResult& cppRepresentation);
OmniusEnums::OAuthResult CHOAuthResultToCPP(CHOAuthResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHPersonCreateResult <=> OmniusEnums::PersonCreateResult
/*****************************************************************************/

CHPersonCreateResult CHPersonCreateResultFromCPP(const OmniusEnums::PersonCreateResult& cppRepresentation);
OmniusEnums::PersonCreateResult CHPersonCreateResultToCPP(CHPersonCreateResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHPersonDeleteResult <=> OmniusEnums::PersonDeleteResult
/*****************************************************************************/

CHPersonDeleteResult CHPersonDeleteResultFromCPP(const OmniusEnums::PersonDeleteResult& cppRepresentation);
OmniusEnums::PersonDeleteResult CHPersonDeleteResultToCPP(CHPersonDeleteResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHPersonGetResult <=> OmniusEnums::PersonGetResult
/*****************************************************************************/

CHPersonGetResult CHPersonGetResultFromCPP(const OmniusEnums::PersonGetResult& cppRepresentation);
OmniusEnums::PersonGetResult CHPersonGetResultToCPP(CHPersonGetResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHPersonUpdateResult <=> OmniusEnums::PersonUpdateResult
/*****************************************************************************/

CHPersonUpdateResult CHPersonUpdateResultFromCPP(const OmniusEnums::PersonUpdateResult& cppRepresentation);
OmniusEnums::PersonUpdateResult CHPersonUpdateResultToCPP(CHPersonUpdateResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHPhoneServiceRegistrationFailureReason <=> OmniusEnums::PhoneServiceRegistrationFailureReason
/*****************************************************************************/

CHPhoneServiceRegistrationFailureReason CHPhoneServiceRegistrationFailureReasonFromCPP(const OmniusEnums::PhoneServiceRegistrationFailureReason& cppRepresentation);
OmniusEnums::PhoneServiceRegistrationFailureReason CHPhoneServiceRegistrationFailureReasonToCPP(CHPhoneServiceRegistrationFailureReason objcRepresentation);

/*****************************************************************************/
#pragma mark - CHPreviewVirtualBackgroundResult <=> OmniusEnums::PreviewVirtualBackgroundResult
/*****************************************************************************/

CHPreviewVirtualBackgroundResult CHPreviewVirtualBackgroundResultFromCPP(const OmniusEnums::PreviewVirtualBackgroundResult& cppRepresentation);
OmniusEnums::PreviewVirtualBackgroundResult CHPreviewVirtualBackgroundResultToCPP(CHPreviewVirtualBackgroundResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHResourceType <=> OmniusEnums::ResourceType
/*****************************************************************************/

CHResourceType CHResourceTypeFromCPP(const OmniusEnums::ResourceType& cppRepresentation);
OmniusEnums::ResourceType CHResourceTypeToCPP(CHResourceType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHReturnToMainSessionResult <=> OmniusEnums::ReturnToMainSessionResult
/*****************************************************************************/

CHReturnToMainSessionResult CHReturnToMainSessionResultFromCPP(const OmniusEnums::ReturnToMainSessionResult& cppRepresentation);
OmniusEnums::ReturnToMainSessionResult CHReturnToMainSessionResultToCPP(CHReturnToMainSessionResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHRole <=> OmniusEnums::Role
/*****************************************************************************/

CHRole CHRoleFromCPP(const OmniusEnums::Role& cppRepresentation);
OmniusEnums::Role CHRoleToCPP(CHRole objcRepresentation);

/*****************************************************************************/
#pragma mark - CHServiceUrlType <=> OmniusEnums::ServiceUrlType
/*****************************************************************************/

CHServiceUrlType CHServiceUrlTypeFromCPP(const OmniusEnums::ServiceUrlType& cppRepresentation);
OmniusEnums::ServiceUrlType CHServiceUrlTypeToCPP(CHServiceUrlType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHSessionType <=> OmniusEnums::SessionType
/*****************************************************************************/

CHSessionType CHSessionTypeFromCPP(const OmniusEnums::SessionType& cppRepresentation);
OmniusEnums::SessionType CHSessionTypeToCPP(CHSessionType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHSetCompositedLayoutResult <=> OmniusEnums::SetCompositedLayoutResult
/*****************************************************************************/

CHSetCompositedLayoutResult CHSetCompositedLayoutResultFromCPP(const OmniusEnums::SetCompositedLayoutResult& cppRepresentation);
OmniusEnums::SetCompositedLayoutResult CHSetCompositedLayoutResultToCPP(CHSetCompositedLayoutResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHSetRemoteVideoRenderModeResult <=> OmniusEnums::SetRemoteVideoRenderModeResult
/*****************************************************************************/

CHSetRemoteVideoRenderModeResult CHSetRemoteVideoRenderModeResultFromCPP(const OmniusEnums::SetRemoteVideoRenderModeResult& cppRepresentation);
OmniusEnums::SetRemoteVideoRenderModeResult CHSetRemoteVideoRenderModeResultToCPP(CHSetRemoteVideoRenderModeResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHShareSourceType <=> OmniusEnums::ShareSourceType
/*****************************************************************************/

CHShareSourceType CHShareSourceTypeFromCPP(const OmniusEnums::ShareSourceType& cppRepresentation);
OmniusEnums::ShareSourceType CHShareSourceTypeToCPP(CHShareSourceType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHSpaceEvent <=> OmniusEnums::SpaceEvent
/*****************************************************************************/

CHSpaceEvent CHSpaceEventFromCPP(const OmniusEnums::SpaceEvent& cppRepresentation);
OmniusEnums::SpaceEvent CHSpaceEventToCPP(CHSpaceEvent objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTeamArchiveResult <=> OmniusEnums::TeamArchiveResult
/*****************************************************************************/

CHTeamArchiveResult CHTeamArchiveResultFromCPP(const OmniusEnums::TeamArchiveResult& cppRepresentation);
OmniusEnums::TeamArchiveResult CHTeamArchiveResultToCPP(CHTeamArchiveResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTeamCreateResult <=> OmniusEnums::TeamCreateResult
/*****************************************************************************/

CHTeamCreateResult CHTeamCreateResultFromCPP(const OmniusEnums::TeamCreateResult& cppRepresentation);
OmniusEnums::TeamCreateResult CHTeamCreateResultToCPP(CHTeamCreateResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTeamGetResult <=> OmniusEnums::TeamGetResult
/*****************************************************************************/

CHTeamGetResult CHTeamGetResultFromCPP(const OmniusEnums::TeamGetResult& cppRepresentation);
OmniusEnums::TeamGetResult CHTeamGetResultToCPP(CHTeamGetResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTeamListResult <=> OmniusEnums::TeamListResult
/*****************************************************************************/

CHTeamListResult CHTeamListResultFromCPP(const OmniusEnums::TeamListResult& cppRepresentation);
OmniusEnums::TeamListResult CHTeamListResultToCPP(CHTeamListResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTeamUpdateResult <=> OmniusEnums::TeamUpdateResult
/*****************************************************************************/

CHTeamUpdateResult CHTeamUpdateResultFromCPP(const OmniusEnums::TeamUpdateResult& cppRepresentation);
OmniusEnums::TeamUpdateResult CHTeamUpdateResultToCPP(CHTeamUpdateResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTelemetry <=> OmniusEnums::Telemetry
/*****************************************************************************/

CHTelemetry CHTelemetryFromCPP(const OmniusEnums::Telemetry& cppRepresentation);
OmniusEnums::Telemetry CHTelemetryToCPP(CHTelemetry objcRepresentation);

/*****************************************************************************/
#pragma mark - CHUCBrowserLoginSSONavResult <=> OmniusEnums::UCBrowserLoginSSONavResult
/*****************************************************************************/

CHUCBrowserLoginSSONavResult CHUCBrowserLoginSSONavResultFromCPP(const OmniusEnums::UCBrowserLoginSSONavResult& cppRepresentation);
OmniusEnums::UCBrowserLoginSSONavResult CHUCBrowserLoginSSONavResultToCPP(CHUCBrowserLoginSSONavResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHUCLoginServerConnectionStatus <=> OmniusEnums::UCLoginServerConnectionStatus
/*****************************************************************************/

CHUCLoginServerConnectionStatus CHUCLoginServerConnectionStatusFromCPP(const OmniusEnums::UCLoginServerConnectionStatus& cppRepresentation);
OmniusEnums::UCLoginServerConnectionStatus CHUCLoginServerConnectionStatusToCPP(CHUCLoginServerConnectionStatus objcRepresentation);

/*****************************************************************************/
#pragma mark - CHUCSSOFailureReason <=> OmniusEnums::UCSSOFailureReason
/*****************************************************************************/

CHUCSSOFailureReason CHUCSSOFailureReasonFromCPP(const OmniusEnums::UCSSOFailureReason& cppRepresentation);
OmniusEnums::UCSSOFailureReason CHUCSSOFailureReasonToCPP(CHUCSSOFailureReason objcRepresentation);

/*****************************************************************************/
#pragma mark - CHUpdateSpaceTitleResult <=> OmniusEnums::UpdateSpaceTitleResult
/*****************************************************************************/

CHUpdateSpaceTitleResult CHUpdateSpaceTitleResultFromCPP(const OmniusEnums::UpdateSpaceTitleResult& cppRepresentation);
OmniusEnums::UpdateSpaceTitleResult CHUpdateSpaceTitleResultToCPP(CHUpdateSpaceTitleResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHUpdateTeamMembershipResult <=> OmniusEnums::UpdateTeamMembershipResult
/*****************************************************************************/

CHUpdateTeamMembershipResult CHUpdateTeamMembershipResultFromCPP(const OmniusEnums::UpdateTeamMembershipResult& cppRepresentation);
OmniusEnums::UpdateTeamMembershipResult CHUpdateTeamMembershipResultToCPP(CHUpdateTeamMembershipResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHUpdateWebhookByIdResult <=> OmniusEnums::UpdateWebhookByIdResult
/*****************************************************************************/

CHUpdateWebhookByIdResult CHUpdateWebhookByIdResultFromCPP(const OmniusEnums::UpdateWebhookByIdResult& cppRepresentation);
OmniusEnums::UpdateWebhookByIdResult CHUpdateWebhookByIdResultToCPP(CHUpdateWebhookByIdResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHUploadVirtualBackgroundResult <=> OmniusEnums::UploadVirtualBackgroundResult
/*****************************************************************************/

CHUploadVirtualBackgroundResult CHUploadVirtualBackgroundResultFromCPP(const OmniusEnums::UploadVirtualBackgroundResult& cppRepresentation);
OmniusEnums::UploadVirtualBackgroundResult CHUploadVirtualBackgroundResultToCPP(CHUploadVirtualBackgroundResult objcRepresentation);

/*****************************************************************************/
#pragma mark - CHVideoFlashMode <=> OmniusEnums::VideoFlashMode
/*****************************************************************************/

CHVideoFlashMode CHVideoFlashModeFromCPP(const OmniusEnums::VideoFlashMode& cppRepresentation);
OmniusEnums::VideoFlashMode CHVideoFlashModeToCPP(CHVideoFlashMode objcRepresentation);

/*****************************************************************************/
#pragma mark - CHVideoRenderMode <=> OmniusEnums::VideoRenderMode
/*****************************************************************************/

CHVideoRenderMode CHVideoRenderModeFromCPP(const OmniusEnums::VideoRenderMode& cppRepresentation);
OmniusEnums::VideoRenderMode CHVideoRenderModeToCPP(CHVideoRenderMode objcRepresentation);

/*****************************************************************************/
#pragma mark - CHVideoStreamMode <=> OmniusEnums::VideoStreamMode
/*****************************************************************************/

CHVideoStreamMode CHVideoStreamModeFromCPP(const OmniusEnums::VideoStreamMode& cppRepresentation);
OmniusEnums::VideoStreamMode CHVideoStreamModeToCPP(CHVideoStreamMode objcRepresentation);

/*****************************************************************************/
#pragma mark - CHVideoTorchMode <=> OmniusEnums::VideoTorchMode
/*****************************************************************************/

CHVideoTorchMode CHVideoTorchModeFromCPP(const OmniusEnums::VideoTorchMode& cppRepresentation);
OmniusEnums::VideoTorchMode CHVideoTorchModeToCPP(CHVideoTorchMode objcRepresentation);

/*****************************************************************************/
#pragma mark - CHVirtualBackgroundType <=> OmniusEnums::VirtualBackgroundType
/*****************************************************************************/

CHVirtualBackgroundType CHVirtualBackgroundTypeFromCPP(const OmniusEnums::VirtualBackgroundType& cppRepresentation);
OmniusEnums::VirtualBackgroundType CHVirtualBackgroundTypeToCPP(CHVirtualBackgroundType objcRepresentation);

/*****************************************************************************/
#pragma mark - CHWebexMeetingEntryPoint <=> OmniusEnums::WebexMeetingEntryPoint
/*****************************************************************************/

CHWebexMeetingEntryPoint CHWebexMeetingEntryPointFromCPP(const OmniusEnums::WebexMeetingEntryPoint& cppRepresentation);
OmniusEnums::WebexMeetingEntryPoint CHWebexMeetingEntryPointToCPP(CHWebexMeetingEntryPoint objcRepresentation);

/*****************************************************************************/
#pragma mark - CHBreakout <=> OmniusModels::Breakout
/*****************************************************************************/

CHBreakout * CHBreakoutFromCPP(const OmniusModels::Breakout& cppRepresentation);
OmniusModels::Breakout CHBreakoutToCPP(CHBreakout *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHBreakoutSession <=> OmniusModels::BreakoutSession
/*****************************************************************************/

CHBreakoutSession * CHBreakoutSessionFromCPP(const OmniusModels::BreakoutSession& cppRepresentation);
OmniusModels::BreakoutSession CHBreakoutSessionToCPP(CHBreakoutSession *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCall <=> OmniusModels::Call
/*****************************************************************************/

CHCall * CHCallFromCPP(const OmniusModels::Call& cppRepresentation);
OmniusModels::Call CHCallToCPP(CHCall *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCallHistoryRecord <=> OmniusModels::CallHistoryRecord
/*****************************************************************************/

CHCallHistoryRecord * CHCallHistoryRecordFromCPP(const OmniusModels::CallHistoryRecord& cppRepresentation);
OmniusModels::CallHistoryRecord CHCallHistoryRecordToCPP(CHCallHistoryRecord *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCallMembership <=> OmniusModels::CallMembership
/*****************************************************************************/

CHCallMembership * CHCallMembershipFromCPP(const OmniusModels::CallMembership& cppRepresentation);
OmniusModels::CallMembership CHCallMembershipToCPP(CHCallMembership *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCameraExposureDuration <=> OmniusModels::CameraExposureDuration
/*****************************************************************************/

CHCameraExposureDuration * CHCameraExposureDurationFromCPP(const OmniusModels::CameraExposureDuration& cppRepresentation);
OmniusModels::CameraExposureDuration CHCameraExposureDurationToCPP(CHCameraExposureDuration *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCameraExposureISO <=> OmniusModels::CameraExposureISO
/*****************************************************************************/

CHCameraExposureISO * CHCameraExposureISOFromCPP(const OmniusModels::CameraExposureISO& cppRepresentation);
OmniusModels::CameraExposureISO CHCameraExposureISOToCPP(CHCameraExposureISO *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCameraExposureTargetBias <=> OmniusModels::CameraExposureTargetBias
/*****************************************************************************/

CHCameraExposureTargetBias * CHCameraExposureTargetBiasFromCPP(const OmniusModels::CameraExposureTargetBias& cppRepresentation);
OmniusModels::CameraExposureTargetBias CHCameraExposureTargetBiasToCPP(CHCameraExposureTargetBias *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHCaptcha <=> OmniusModels::Captcha
/*****************************************************************************/

CHCaptcha * CHCaptchaFromCPP(const OmniusModels::Captcha& cppRepresentation);
OmniusModels::Captcha CHCaptchaToCPP(CHCaptcha *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHEmailAddress <=> OmniusModels::EmailAddress
/*****************************************************************************/

CHEmailAddress * CHEmailAddressFromCPP(const OmniusModels::EmailAddress& cppRepresentation);
OmniusModels::EmailAddress CHEmailAddressToCPP(CHEmailAddress *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHInvitee <=> OmniusModels::Invitee
/*****************************************************************************/

CHInvitee * CHInviteeFromCPP(const OmniusModels::Invitee& cppRepresentation);
OmniusModels::Invitee CHInviteeToCPP(CHInvitee *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHJoinMeetingParam <=> OmniusModels::JoinMeetingParam
/*****************************************************************************/

CHJoinMeetingParam * CHJoinMeetingParamFromCPP(const OmniusModels::JoinMeetingParam& cppRepresentation);
OmniusModels::JoinMeetingParam CHJoinMeetingParamToCPP(CHJoinMeetingParam *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHKeyValues <=> OmniusModels::KeyValues
/*****************************************************************************/

CHKeyValues * CHKeyValuesFromCPP(const OmniusModels::KeyValues& cppRepresentation);
OmniusModels::KeyValues CHKeyValuesToCPP(CHKeyValues *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHLocalFile <=> OmniusModels::LocalFile
/*****************************************************************************/

CHLocalFile * CHLocalFileFromCPP(const OmniusModels::LocalFile& cppRepresentation);
OmniusModels::LocalFile CHLocalFileToCPP(CHLocalFile *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMediaStream <=> OmniusModels::MediaStream
/*****************************************************************************/

CHMediaStream * CHMediaStreamFromCPP(const OmniusModels::MediaStream& cppRepresentation);
OmniusModels::MediaStream CHMediaStreamToCPP(CHMediaStream *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMediaStreamChangeEventInfo <=> OmniusModels::MediaStreamChangeEventInfo
/*****************************************************************************/

CHMediaStreamChangeEventInfo * CHMediaStreamChangeEventInfoFromCPP(const OmniusModels::MediaStreamChangeEventInfo& cppRepresentation);
OmniusModels::MediaStreamChangeEventInfo CHMediaStreamChangeEventInfoToCPP(CHMediaStreamChangeEventInfo *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMeeting <=> OmniusModels::Meeting
/*****************************************************************************/

CHMeeting * CHMeetingFromCPP(const OmniusModels::Meeting& cppRepresentation);
OmniusModels::Meeting CHMeetingToCPP(CHMeeting *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMeetingInfo <=> OmniusModels::MeetingInfo
/*****************************************************************************/

CHMeetingInfo * CHMeetingInfoFromCPP(const OmniusModels::MeetingInfo& cppRepresentation);
OmniusModels::MeetingInfo CHMeetingInfoToCPP(CHMeetingInfo *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMeetingJoinSuggestion <=> OmniusModels::MeetingJoinSuggestion
/*****************************************************************************/

CHMeetingJoinSuggestion * CHMeetingJoinSuggestionFromCPP(const OmniusModels::MeetingJoinSuggestion& cppRepresentation);
OmniusModels::MeetingJoinSuggestion CHMeetingJoinSuggestionToCPP(CHMeetingJoinSuggestion *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMembership <=> OmniusModels::Membership
/*****************************************************************************/

CHMembership * CHMembershipFromCPP(const OmniusModels::Membership& cppRepresentation);
OmniusModels::Membership CHMembershipToCPP(CHMembership *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMembershipId <=> OmniusModels::MembershipId
/*****************************************************************************/

CHMembershipId * CHMembershipIdFromCPP(const OmniusModels::MembershipId& cppRepresentation);
OmniusModels::MembershipId CHMembershipIdToCPP(CHMembershipId *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMembershipReadStatus <=> OmniusModels::MembershipReadStatus
/*****************************************************************************/

CHMembershipReadStatus * CHMembershipReadStatusFromCPP(const OmniusModels::MembershipReadStatus& cppRepresentation);
OmniusModels::MembershipReadStatus CHMembershipReadStatusToCPP(CHMembershipReadStatus *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMention <=> OmniusModels::Mention
/*****************************************************************************/

CHMention * CHMentionFromCPP(const OmniusModels::Mention& cppRepresentation);
OmniusModels::Mention CHMentionToCPP(CHMention *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMessage <=> OmniusModels::Message
/*****************************************************************************/

CHMessage * CHMessageFromCPP(const OmniusModels::Message& cppRepresentation);
OmniusModels::Message CHMessageToCPP(CHMessage *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHMessageText <=> OmniusModels::MessageText
/*****************************************************************************/

CHMessageText * CHMessageTextFromCPP(const OmniusModels::MessageText& cppRepresentation);
OmniusModels::MessageText CHMessageTextToCPP(CHMessageText *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHPerson <=> OmniusModels::Person
/*****************************************************************************/

CHPerson * CHPersonFromCPP(const OmniusModels::Person& cppRepresentation);
OmniusModels::Person CHPersonToCPP(CHPerson *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHRemoteFile <=> OmniusModels::RemoteFile
/*****************************************************************************/

CHRemoteFile * CHRemoteFileFromCPP(const OmniusModels::RemoteFile& cppRepresentation);
OmniusModels::RemoteFile CHRemoteFileToCPP(CHRemoteFile *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHResource <=> OmniusModels::Resource
/*****************************************************************************/

CHResource * CHResourceFromCPP(const OmniusModels::Resource& cppRepresentation);
OmniusModels::Resource CHResourceToCPP(CHResource *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHSpace <=> OmniusModels::Space
/*****************************************************************************/

CHSpace * CHSpaceFromCPP(const OmniusModels::Space& cppRepresentation);
OmniusModels::Space CHSpaceToCPP(CHSpace *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHSpaceApiErrorInfo <=> OmniusModels::SpaceApiErrorInfo
/*****************************************************************************/

CHSpaceApiErrorInfo * CHSpaceApiErrorInfoFromCPP(const OmniusModels::SpaceApiErrorInfo& cppRepresentation);
OmniusModels::SpaceApiErrorInfo CHSpaceApiErrorInfoToCPP(CHSpaceApiErrorInfo *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHSpaceMeetingInfo <=> OmniusModels::SpaceMeetingInfo
/*****************************************************************************/

CHSpaceMeetingInfo * CHSpaceMeetingInfoFromCPP(const OmniusModels::SpaceMeetingInfo& cppRepresentation);
OmniusModels::SpaceMeetingInfo CHSpaceMeetingInfoToCPP(CHSpaceMeetingInfo *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHSpaceReadStatus <=> OmniusModels::SpaceReadStatus
/*****************************************************************************/

CHSpaceReadStatus * CHSpaceReadStatusFromCPP(const OmniusModels::SpaceReadStatus& cppRepresentation);
OmniusModels::SpaceReadStatus CHSpaceReadStatusToCPP(CHSpaceReadStatus *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTeam <=> OmniusModels::Team
/*****************************************************************************/

CHTeam * CHTeamFromCPP(const OmniusModels::Team& cppRepresentation);
OmniusModels::Team CHTeamToCPP(CHTeam *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTeamMembership <=> OmniusModels::TeamMembership
/*****************************************************************************/

CHTeamMembership * CHTeamMembershipFromCPP(const OmniusModels::TeamMembership& cppRepresentation);
OmniusModels::TeamMembership CHTeamMembershipToCPP(CHTeamMembership *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTeamMembershipId <=> OmniusModels::TeamMembershipId
/*****************************************************************************/

CHTeamMembershipId * CHTeamMembershipIdFromCPP(const OmniusModels::TeamMembershipId& cppRepresentation);
OmniusModels::TeamMembershipId CHTeamMembershipIdToCPP(CHTeamMembershipId *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHTranscription <=> OmniusModels::Transcription
/*****************************************************************************/

CHTranscription * CHTranscriptionFromCPP(const OmniusModels::Transcription& cppRepresentation);
OmniusModels::Transcription CHTranscriptionToCPP(CHTranscription *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHVideoFrameSize <=> OmniusModels::VideoFrameSize
/*****************************************************************************/

CHVideoFrameSize * CHVideoFrameSizeFromCPP(const OmniusModels::VideoFrameSize& cppRepresentation);
OmniusModels::VideoFrameSize CHVideoFrameSizeToCPP(CHVideoFrameSize *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHVirtualBackgroundItem <=> OmniusModels::VirtualBackgroundItem
/*****************************************************************************/

CHVirtualBackgroundItem * CHVirtualBackgroundItemFromCPP(const OmniusModels::VirtualBackgroundItem& cppRepresentation);
OmniusModels::VirtualBackgroundItem CHVirtualBackgroundItemToCPP(CHVirtualBackgroundItem *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHVirtualBackgroundThumbnail <=> OmniusModels::VirtualBackgroundThumbnail
/*****************************************************************************/

CHVirtualBackgroundThumbnail * CHVirtualBackgroundThumbnailFromCPP(const OmniusModels::VirtualBackgroundThumbnail& cppRepresentation);
OmniusModels::VirtualBackgroundThumbnail CHVirtualBackgroundThumbnailToCPP(CHVirtualBackgroundThumbnail *objcRepresentation);

/*****************************************************************************/
#pragma mark - CHWebhook <=> OmniusModels::Webhook
/*****************************************************************************/

CHWebhook * CHWebhookFromCPP(const OmniusModels::Webhook& cppRepresentation);
OmniusModels::Webhook CHWebhookToCPP(CHWebhook *objcRepresentation);


NS_ASSUME_NONNULL_END
#endif
#endif

