#import <Foundation/Foundation.h>

// This must be kept in sync with the enum defined in RootLogger.h (C++)
typedef NS_ENUM(NSInteger, RootLoggerLevel) {
    UnknownLoggerLevel = 0,
    Trace,
    Detail,
    Debug,
    Info,
    Warn,
    Error,
    Private,
    Test
};

typedef NS_ENUM(NSInteger, LogLevel) {
    LogLevelError,
    LogLevelWarn,
    LogLevelInfo,
    LogLevelVerbose,
    LogLevelPrivate // This is a special log level which is used to conditionally log PII.
};

@interface RootLoggerImpl : NSObject
+ (RootLoggerImpl*)sharedInstance;
- (void) configLogger:(NSURL *)logsDirectory;
- (void) setLogFilterLevel:(RootLoggerLevel)level;
- (void) enableCoutLogger:(BOOL)enable;
- (void) logMessage:(NSString*)msg atLevel:(RootLoggerLevel)level withLine:(int)lineNumber inFile:(const char *)filename inFunction:(const char *)fnName;
- (void) clear;
- (void) prepareExit;
@end
