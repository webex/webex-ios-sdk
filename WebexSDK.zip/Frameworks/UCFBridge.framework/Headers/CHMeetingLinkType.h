// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHMeetingLinkType_IMPORTED
#define CHMeetingLinkType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHMeetingLinkType) {
    CHMeetingLinkTypeUnknown,
    CHMeetingLinkTypePMR,
    CHMeetingLinkTypeSIP_Webex,
    CHMeetingLinkTypeSIP_Spark,
    CHMeetingLinkTypeInvitation,
    CHMeetingLinkTypeBrowser,
    CHMeetingLinkTypeBrowserCross,
    CHMeetingLinkTypeSpace_Webex,
    CHMeetingLinkTypeSpace_Spark,
    CHMeetingLinkTypeThirdparty
};

#endif

