// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHNotificationCallType_IMPORTED
#define CHNotificationCallType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHNotificationCallType) {
    CHNotificationCallTypeWebex,
    CHNotificationCallTypeCucm
};

#endif

