// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHVideoFlashMode_IMPORTED
#define CHVideoFlashMode_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHVideoFlashMode) {
    CHVideoFlashModeVideoFlashModeOff,
    CHVideoFlashModeVideoFlashModeOn,
    CHVideoFlashModeVideoFlashModeAuto
};

#endif

