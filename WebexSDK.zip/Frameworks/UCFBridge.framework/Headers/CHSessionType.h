// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHSessionType_IMPORTED
#define CHSessionType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHSessionType) {
    CHSessionTypeUnknown,
    CHSessionTypeAD_HOC,
    CHSessionTypeADHOC_UNIFIED_SPACE_MEETING,
    CHSessionTypeSPACE_MEETING
};

#endif

