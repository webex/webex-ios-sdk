// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHMediaStreamType_IMPORTED
#define CHMediaStreamType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHMediaStreamType) {
    CHMediaStreamTypeUnknown,
    CHMediaStreamTypeLocal,
    CHMediaStreamTypeRemote,
    CHMediaStreamTypeRemoteAux1,
    CHMediaStreamTypeRemoteAux2,
    CHMediaStreamTypeRemoteAux3,
    CHMediaStreamTypeRemoteAux4,
    CHMediaStreamTypeRemoteAux5,
    CHMediaStreamTypeRemoteAux6,
    CHMediaStreamTypeRemoteAux7,
    CHMediaStreamTypeRemoteAux8,
    CHMediaStreamTypeRemoteAux9,
    CHMediaStreamTypeRemoteAux10,
    CHMediaStreamTypeRemoteAux11,
    CHMediaStreamTypeRemoteAux12,
    CHMediaStreamTypeRemoteAux13,
    CHMediaStreamTypeRemoteAux14,
    CHMediaStreamTypeRemoteAux15,
    CHMediaStreamTypeRemoteAux16,
    CHMediaStreamTypeRemoteAux17,
    CHMediaStreamTypeRemoteAux18,
    CHMediaStreamTypeRemoteAux19,
    CHMediaStreamTypeRemoteAux20,
    CHMediaStreamTypeRemoteAux21,
    CHMediaStreamTypeRemoteAux22,
    CHMediaStreamTypeRemoteAux23,
    CHMediaStreamTypeRemoteAux24,
    CHMediaStreamTypeRemoteAuxEnd,
    CHMediaStreamTypeLocalShare,
    CHMediaStreamTypeRemoteShare
};

#endif

