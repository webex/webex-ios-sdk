// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHConversationType_IMPORTED
#define CHConversationType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHConversationType) {
    CHConversationTypedirect,
    CHConversationTypegroup,
    CHConversationTypenone
};

#endif

