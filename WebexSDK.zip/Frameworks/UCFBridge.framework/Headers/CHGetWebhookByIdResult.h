// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHGetWebhookByIdResult_IMPORTED
#define CHGetWebhookByIdResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHGetWebhookByIdResult) {
    CHGetWebhookByIdResultNoError,
    CHGetWebhookByIdResultInternalError,
    CHGetWebhookByIdResultWebhookNotFound,
    CHGetWebhookByIdResultBadRequest
};

#endif

