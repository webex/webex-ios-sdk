// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHMediaStreamChangeEventType_IMPORTED
#define CHMediaStreamChangeEventType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHMediaStreamChangeEventType) {
    CHMediaStreamChangeEventTypeSize,
    CHMediaStreamChangeEventTypeMembership,
    CHMediaStreamChangeEventTypeVideo,
    CHMediaStreamChangeEventTypeAudio,
    CHMediaStreamChangeEventTypePinState
};

#endif

