// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHWebexMeetingEntryPoint_IMPORTED
#define CHWebexMeetingEntryPoint_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHWebexMeetingEntryPoint) {
    CHWebexMeetingEntryPointUnknown,
    CHWebexMeetingEntryPointMyPMR,
    CHWebexMeetingEntryPointCalendar,
    CHWebexMeetingEntryPointContactCard,
    CHWebexMeetingEntryPointConversationList,
    CHWebexMeetingEntryPointNotification,
    CHWebexMeetingEntryPointChatMessage,
    CHWebexMeetingEntryPointJoinMeetingButtonInMeetingsView,
    CHWebexMeetingEntryPointManualDialIn,
    CHWebexMeetingEntryPointCallHistory,
    CHWebexMeetingEntryPointJoinMeetingButtonOnTopRightofConversation,
    CHWebexMeetingEntryPointIngoreEntryWithShowSpinWindow,
    CHWebexMeetingEntryPointMeetingCaptcha,
    CHWebexMeetingEntryPointMeetingWidget,
    CHWebexMeetingEntryPointCallEscalation,
    CHWebexMeetingEntryPointWebBrowser,
    CHWebexMeetingEntryPointGuestJoin,
    CHWebexMeetingEntryPointDevicePanel,
    CHWebexMeetingEntryPointHomeTab
};

#endif

