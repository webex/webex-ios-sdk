// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHTeamGetResult_IMPORTED
#define CHTeamGetResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHTeamGetResult) {
    CHTeamGetResultNoError,
    CHTeamGetResultInternalError,
    CHTeamGetResultTeamNotFound
};

#endif

