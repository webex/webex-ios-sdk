// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHShareSourceType_IMPORTED
#define CHShareSourceType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHShareSourceType) {
    CHShareSourceTypeUnknown,
    CHShareSourceTypeDesktop,
    CHShareSourceTypeApplication,
    CHShareSourceTypeContent,
    CHShareSourceTypeWindow,
    CHShareSourceTypePortion,
    CHShareSourceTypeAndroid,
    CHShareSourceTypeiOS
};

#endif

