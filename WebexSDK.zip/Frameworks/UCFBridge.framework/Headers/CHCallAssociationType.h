// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHCallAssociationType_IMPORTED
#define CHCallAssociationType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHCallAssociationType) {
    CHCallAssociationTypeUndefined,
    CHCallAssociationTypeTransfer,
    CHCallAssociationTypeMerge
};

#endif

