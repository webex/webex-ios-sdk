#import <Foundation/Foundation.h>

#ifndef AppleMercuryNetworkConnectionDelegate_h
#define AppleMercuryNetworkConnectionDelegate_h

NS_ASSUME_NONNULL_BEGIN

@protocol AppleMercuryNetworkConnectionDelegate

- (int)initialise;
- (void)connectToMercury:(NSString*)mercuryUrl bearerToken:(NSString*)bearerToken proxyAddress:(NSString*)proxyAddress proxyUsername:(NSString*)proxyUsername proxyPassword:(NSString*)proxyPassword appVersion:(NSString*)appVersion isDeveloper:(bool)isDeveloper startTime:(time_t)startTime timeoutPings:(bool)timeoutPings;
- (void)pingMercury;
- (void)pongMercury;
- (void)disconnect;
- (void)terminate;
- (void)sendMessage:(NSString*)json;

@end

@protocol AppleMercuryNetworkConnectionProviderProtocol

- (void)createConnection;

// Add more functions below as needed to fulfill the necessary network::IMercuryNetworkConnectionCallback interface.
// MercuryResponse structs cannot be imported, so function parameters map those

// Parameters match network::MercuryDisconnectReason struct
- (void)onMercuryConnectionLost:(NSString*)mercuryUrl avoidReconnect:(bool)avoidReconnect maintenanceShutdown:(bool)maintenanceShutdown authError:(bool)authError wdmError:(bool)wdmError closeStatus:(int)closeStatus connectStartTime:(time_t)connectStartTime;

// Parameters match network::MercuryConnected struct
- (void)onMercuryConnected:(NSString*)mercuryUrl certficateError:(int)certficateError mitmCertificate:(bool)mitmCertificate restrictedNetwork:(bool)restrictedNetwork;

// Parameters match network::MercuryResponse struct. This struct has two constructors, so requires two different functions
- (void)onFailedToCreateConnection:(NSString*)mercuryUrl errorCode:(int)errorCode connectStartTime:(time_t)connectStartTime explanation:(NSString*)explanation httpStatusCode:(int)httpStatusCode proxyUrl:(NSString*)proxyUrl certficateError:(int)certficateError mitmCertficate:(bool)mitmCertficate;
- (void)onFailedToCreateConnection:(NSString*)mercuryUrl errorCode:(int)errorCode certsStringInfo:(NSString*)certsStringInfo didCertPinningFail:(bool)didCertPinningFail certificateError:(int)certficateError mitmCertificate:(bool)mitmCertificate;

- (void)onMercuryEventArrived:(NSString*)json;

NS_ASSUME_NONNULL_END

@property (nonatomic, weak) id<AppleMercuryNetworkConnectionDelegate> _Nullable delegate;

@end

#endif /* AppleMercuryNetworkConnectionDelegate_h */
