// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHUpdateTeamMembershipResult_IMPORTED
#define CHUpdateTeamMembershipResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHUpdateTeamMembershipResult) {
    CHUpdateTeamMembershipResultNoError,
    CHUpdateTeamMembershipResultInternalError,
    CHUpdateTeamMembershipResultInvalidTeamMembershipId,
    CHUpdateTeamMembershipResultTeamNotFound,
    CHUpdateTeamMembershipResultSpaceIsProvisional,
    CHUpdateTeamMembershipResultInsufficientTeamPrivileges,
    CHUpdateTeamMembershipResultFailedToRemoveModerator
};

#endif

