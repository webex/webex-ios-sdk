// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHTeamArchiveResult_IMPORTED
#define CHTeamArchiveResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHTeamArchiveResult) {
    CHTeamArchiveResultNoError,
    CHTeamArchiveResultInternalError,
    CHTeamArchiveResultTeamNotFound,
    CHTeamArchiveResultAlreadyArchived,
    CHTeamArchiveResultUserIsNotModerator,
    CHTeamArchiveResultArchiveFailed
};

#endif

