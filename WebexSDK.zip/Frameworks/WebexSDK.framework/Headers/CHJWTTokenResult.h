// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHJWTTokenResult_IMPORTED
#define CHJWTTokenResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHJWTTokenResult) {
    CHJWTTokenResultNoError,
    CHJWTTokenResultInternalError,
    CHJWTTokenResultTokenExpiryMissing,
    CHJWTTokenResultTokenExpired,
    CHJWTTokenResultFedRAMPError,
    CHJWTTokenResultInvalidToken
};

#endif

