// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHServiceUrlType_IMPORTED
#define CHServiceUrlType_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHServiceUrlType) {
    CHServiceUrlTypeMetrics,
    CHServiceUrlTypeClient_Logs,
    CHServiceUrlTypeKMS
};

#endif

