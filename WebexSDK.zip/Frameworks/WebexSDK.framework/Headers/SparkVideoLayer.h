//
//  SparkVideoRender.h
//  SparkMacDesktop
//
//  Created by jimmcoyn on 05/10/2016.
//  Copyright © 2016 Cisco Systems. All rights reserved.
//

#ifndef SparkVideoLayer_h
#define SparkVideoLayer_h

#import "CocoaFrameworks.h"

typedef enum : NSUInteger {
    VideoRenderTypeDefault,
    VideoRenderTypeRemote,
    VideoRenderTypeLocal,
    VideoRenderTypeCustom = VideoRenderTypeLocal,
} VideoRenderType;


#if TARGET_OS_IPHONE
@interface SparkVideoLayer : UIView
#else

#import "LayerBackedOpenGLRenderView.h"
@protocol SparkVideoLayerDelegate <NSObject>
-(void)videoZoomUpdate:(float) newValue;

@end

@interface SparkVideoLayer : NSView
- (instancetype)initWithFrame:(NSRect)frameRect;
-(instancetype)initWithCoder:(NSCoder *)coder;
-(void)setIsCircular:(bool)value;
-(void) setFillViewKeepingAspectRatio:(bool)bFill;
-(void) clearProperties;
-(void) useDarkLetterBoxing:(bool)bShouldUseDark;
-(CGFloat) getPillarboxPercent;
-(CGFloat) getLetterboxPercent;

+(float)zoomMinValue;
+(float)zoomMaxValue;

-(void) zoomInWithValue:(float)zoomValue;
-(void) zoomOutWithValue:(float)zoomValue;
-(void) resetZoom;
-(float) getZoomLevel;
-(CGPoint) getDragPos;
- (CGFloat) getBackingScaled;
-(void) updateDragPos:(CGPoint)dragPos;
-(void) remoteControl:(bool)isSessionEstablished;

@property (nonatomic, assign) BOOL allowZoom;
@property (nonatomic) bool mirrored;
@property (nonatomic) VideoFrameType videoFrameType;
@property (nonatomic, weak) id<SparkVideoLayerDelegate> delegate;
#endif

-(CCView *) getRenderView;
-(void)allowDrawFrame:(bool)bAllow;
-(void)useVideoRenderType:(VideoRenderType)type;
-(void)useCustomRenderer:(bool)value;

@end

#endif // SparkVideoLayer_h
