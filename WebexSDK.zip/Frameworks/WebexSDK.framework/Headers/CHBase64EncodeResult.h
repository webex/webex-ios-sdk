// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHBase64EncodeResult_IMPORTED
#define CHBase64EncodeResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHBase64EncodeResult) {
    CHBase64EncodeResultNoError,
    CHBase64EncodeResultInternalError,
    CHBase64EncodeResultAlreadyEncoded,
    CHBase64EncodeResultBadRequest
};

#endif

