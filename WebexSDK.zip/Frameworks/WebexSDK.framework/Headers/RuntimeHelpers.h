#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXTERN BOOL IsDebuggerAttached(void);
FOUNDATION_EXTERN void BreakIntoDebugger(void);
FOUNDATION_EXTERN NSString *_Nullable AtosCommandForCallStackReturnAddresses(NSArray<NSNumber *> *callStackReturnAddresses);
FOUNDATION_EXTERN NSException *_Nullable ExecuteThrowableBlock(void NS_NOESCAPE (^block)(void));
FOUNDATION_EXTERN void ExecuteFatalThrowableBlock(void NS_NOESCAPE (^block)(void));

NS_ASSUME_NONNULL_END
