// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHPreviewVirtualBackgroundResult_IMPORTED
#define CHPreviewVirtualBackgroundResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHPreviewVirtualBackgroundResult) {
    CHPreviewVirtualBackgroundResultNoError,
    CHPreviewVirtualBackgroundResultInternalError,
    CHPreviewVirtualBackgroundResultNotFound
};

#endif

