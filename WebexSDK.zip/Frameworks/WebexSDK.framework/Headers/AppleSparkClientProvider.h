#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol AppleSparkClientProvider

@property (nonatomic, readonly) NSString *userAgent;
@property (nonatomic, readonly) NSString *oauthClientId;
@property (nonatomic, readonly) NSString *oauthClientSecret;
@property (nonatomic, readonly) NSString *oauthAdditionalScopes;
@property (nonatomic, readonly) NSString *oauthRedirectUri;

// Add more properties as needed to fulfill the necessary ISparkClient interface.
@property (nonatomic, readonly) NSString *applicationVersion;
@property (nonatomic, readonly) NSString *operatingSystemVersion;
@property (nonatomic, readonly) NSString *operatingSystemLanguage;
@property (nonatomic, readonly) NSString *platformInfo;
@property (nonatomic, readonly) NSString *databasePath;
@property (nonatomic, readonly) NSString *wdmDeviceType;
@property (nonatomic, readonly) NSString *platformEncryptionIdentifier;
@property (nonatomic, readonly) NSString *appType;
- (nullable NSString *)extraTelemetryMetaDataForMetricEventName:(NSString *)metricEventName;
@property (nonatomic, readonly) NSString *productName;
@property (nonatomic, readonly, getter=isDeveloperVersion) BOOL developerVersion;
@property (nonatomic, readonly, getter=isTablet) BOOL tablet;
@property (nonatomic, readonly) NSString *appleAccessGroupIdentifier;
- (nullable NSString *)additionalClientConfigForConfigName:(NSString *)configName;

@property (nonatomic, readonly) NSString *u2cUrl;

@end

NS_ASSUME_NONNULL_END
