// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHGetMembershipByIdResult_IMPORTED
#define CHGetMembershipByIdResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHGetMembershipByIdResult) {
    CHGetMembershipByIdResultInternalError,
    CHGetMembershipByIdResultInvalidMembershipId,
    CHGetMembershipByIdResultNoError
};

#endif

