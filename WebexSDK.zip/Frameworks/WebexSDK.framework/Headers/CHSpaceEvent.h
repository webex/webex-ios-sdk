// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHSpaceEvent_IMPORTED
#define CHSpaceEvent_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHSpaceEvent) {
    CHSpaceEventCreate,
    CHSpaceEventUpdate,
    CHSpaceEventSpaceCallStarted,
    CHSpaceEventSpaceCallEnded
};

#endif

