// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHDeleteMessageResult_IMPORTED
#define CHDeleteMessageResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHDeleteMessageResult) {
    CHDeleteMessageResultNoError,
    CHDeleteMessageResultInternalError,
    CHDeleteMessageResultInvalidMessageId
};

#endif

