// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHCallMembershipState_IMPORTED
#define CHCallMembershipState_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHCallMembershipState) {
    CHCallMembershipStateUNKNOWN,
    CHCallMembershipStateIDLE,
    CHCallMembershipStateNOTIFIED,
    CHCallMembershipStateJOINED,
    CHCallMembershipStateLEFT,
    CHCallMembershipStateDECLINED,
    CHCallMembershipStateWAITING
};

#endif

