#import <Foundation/Foundation.h>
#import "WebexBroadcastCallServerProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface BroadcastUtil : NSObject
@property (weak, nonatomic) id<WebexBroadcastCallServerProtocol> delegate;
- (BOOL) isBroadcastFrameworkAvailable;
- (void) initScreenShareService;
- (void) sharingStateChanged: (BOOL) sendingScreenShare;
- (void) suspend;
- (void) closeScreenShare;
@end

NS_ASSUME_NONNULL_END
