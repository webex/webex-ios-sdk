// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHVideoRenderMode_IMPORTED
#define CHVideoRenderMode_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHVideoRenderMode) {
    CHVideoRenderModeFit,
    CHVideoRenderModeCropFill,
    CHVideoRenderModeStretchFill
};

#endif

