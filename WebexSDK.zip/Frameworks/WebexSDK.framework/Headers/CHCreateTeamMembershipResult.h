// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHCreateTeamMembershipResult_IMPORTED
#define CHCreateTeamMembershipResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHCreateTeamMembershipResult) {
    CHCreateTeamMembershipResultNoError,
    CHCreateTeamMembershipResultInternalError,
    CHCreateTeamMembershipResultInvalidTeamId,
    CHCreateTeamMembershipResultTeamNotFound,
    CHCreateTeamMembershipResultNonModeratorCannotAddToModeratedTeam,
    CHCreateTeamMembershipResultUserDoesntExistInOrg,
    CHCreateTeamMembershipResultExternalUserNotAllowed,
    CHCreateTeamMembershipResultCompanyPolicyPreventsMembershipCreation,
    CHCreateTeamMembershipResultBotCannotBeAdded,
    CHCreateTeamMembershipResultBotCannotBeAddedToDirectSpace,
    CHCreateTeamMembershipResultTeamGuestMemberNotEntitled,
    CHCreateTeamMembershipResultUserNotPartOfTeamOffice365,
    CHCreateTeamMembershipResultUserNotPartOfOrganizationOffice365,
    CHCreateTeamMembershipResultFailedToSetModerator,
    CHCreateTeamMembershipResultFailedOperationDisallowedForCommercialGuest
};

#endif

