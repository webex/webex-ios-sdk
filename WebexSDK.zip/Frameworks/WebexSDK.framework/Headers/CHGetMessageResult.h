// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHGetMessageResult_IMPORTED
#define CHGetMessageResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHGetMessageResult) {
    CHGetMessageResultInternalError,
    CHGetMessageResultInvalidMessageId,
    CHGetMessageResultNoError
};

#endif

