// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHUCLoginServerConnectionStatus_IMPORTED
#define CHUCLoginServerConnectionStatus_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHUCLoginServerConnectionStatus) {
    CHUCLoginServerConnectionStatusIdle,
    CHUCLoginServerConnectionStatusConnecting,
    CHUCLoginServerConnectionStatusConnected,
    CHUCLoginServerConnectionStatusDisconnected,
    CHUCLoginServerConnectionStatusFailed
};

#endif

