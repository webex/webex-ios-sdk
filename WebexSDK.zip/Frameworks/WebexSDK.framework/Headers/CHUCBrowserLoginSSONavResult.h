// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHUCBrowserLoginSSONavResult_IMPORTED
#define CHUCBrowserLoginSSONavResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHUCBrowserLoginSSONavResult) {
    CHUCBrowserLoginSSONavResultSuccess,
    CHUCBrowserLoginSSONavResultFailedWith4xx,
    CHUCBrowserLoginSSONavResultFailedWith5xx,
    CHUCBrowserLoginSSONavResultUnknownError,
    CHUCBrowserLoginSSONavResultFailedWithCertError
};

#endif

