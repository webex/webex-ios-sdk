// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHSetRemoteVideoRenderModeResult_IMPORTED
#define CHSetRemoteVideoRenderModeResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHSetRemoteVideoRenderModeResult) {
    CHSetRemoteVideoRenderModeResultIllegal,
    CHSetRemoteVideoRenderModeResultNoError,
    CHSetRemoteVideoRenderModeResultInternalError,
    CHSetRemoteVideoRenderModeResultCallNotFound,
    CHSetRemoteVideoRenderModeResultNotSupported
};

#endif

