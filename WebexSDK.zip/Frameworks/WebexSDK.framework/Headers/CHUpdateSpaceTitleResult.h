// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHUpdateSpaceTitleResult_IMPORTED
#define CHUpdateSpaceTitleResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHUpdateSpaceTitleResult) {
    CHUpdateSpaceTitleResultNoError,
    CHUpdateSpaceTitleResultInvalidSpaceId,
    CHUpdateSpaceTitleResultFailedToUpdateSpaceTitle,
    CHUpdateSpaceTitleResultTitleCannotBeEmpty,
    CHUpdateSpaceTitleResultInternalError
};

#endif

