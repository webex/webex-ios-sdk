// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHListTeamMembershipResult_IMPORTED
#define CHListTeamMembershipResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHListTeamMembershipResult) {
    CHListTeamMembershipResultNoError,
    CHListTeamMembershipResultInternalError,
    CHListTeamMembershipResultTeamNotFound,
    CHListTeamMembershipResultBadRequest
};

#endif

