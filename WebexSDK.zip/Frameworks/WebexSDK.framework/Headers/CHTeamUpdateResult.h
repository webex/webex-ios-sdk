// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHTeamUpdateResult_IMPORTED
#define CHTeamUpdateResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHTeamUpdateResult) {
    CHTeamUpdateResultNoError,
    CHTeamUpdateResultInternalError,
    CHTeamUpdateResultTeamNotFound,
    CHTeamUpdateResultInvalidTeamName
};

#endif

