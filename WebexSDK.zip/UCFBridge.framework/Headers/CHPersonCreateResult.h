// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHPersonCreateResult_IMPORTED
#define CHPersonCreateResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHPersonCreateResult) {
    CHPersonCreateResultNoError,
    CHPersonCreateResultInternalError,
    CHPersonCreateResultUnauthorized,
    CHPersonCreateResultBadRequest,
    CHPersonCreateResultForbidden
};

#endif

