//
//  Frameworks.h
//  SparkMacDesktop
//
//  Created by jimmcoyn on 27/08/2015.
//  Copyright © 2015 Cisco Systems. All rights reserved.
//

#ifndef Frameworks_h
#define Frameworks_h

#import <Foundation/Foundation.h>

#if TARGET_OS_IPHONE
#import <UIKit/UIKit.h>
#else
#import <Cocoa/Cocoa.h>
#import <Quartz/Quartz.h>
#endif


#import <WebKit/WebKit.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <netinet/in.h>




#endif /* Frameworks_h */
