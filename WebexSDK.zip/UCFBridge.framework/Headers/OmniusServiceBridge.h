#ifndef CHOmniusServiceBridge_IMPORTED
#define CHOmniusServiceBridge_IMPORTED
#import <Foundation/Foundation.h>
#include "OmniusServiceBridgeProtocol.h"

@interface OmniusServiceBridge : NSObject<OmniusServiceBridgeProtocol>

@property(nonatomic, weak) id<OmniusServiceBridgeDelegate> _Nullable delegate;

- (nonnull instancetype)initWithSparkClientProvider:(nonnull id<AppleSparkClientProvider>)sparkClientProvider;

- (void)getAuthorizationUrl:(NSString * _Nonnull)email callback:(GetOAuthUrlCompletionFuncCallback _Nonnull )callback;
- (void)signOut:(_Nonnull VoidCompletionFuncCallback) callback;
- (void)appTransition:(BOOL)isInBackground;
- (bool)isLoggedIn;
- (void)attemptToLoginWithCachedUser:(_Nonnull SingleBoolCompletionFuncCallback) callback;
- (void)loginWithAuthCode:(NSString * _Nonnull)authCode emailId:(NSString * _Nonnull)emailId callback:(_Nonnull OAuthResultCompletionFuncCallback) callback;
- (void)loginWithJWT:(NSString * _Nonnull)jwt callback:(GuestIssuerResultCompletionFuncCallback _Nonnull)callback;
- (void)loginWithAccessToken:(NSString * _Nonnull)accessToken expiresInSeconds:(NSNumber * _Nullable) expiresInSeconds callback:(AccessTokenLoginResultCompletionFuncCallback _Nonnull)callback;
- (void)setOnTokenExpiredListener:(VoidCompletionFuncCallback _Nullable ) callback;
- (void)getAccessToken:(AccessTokenResultCompletionFuncCallback _Nonnull ) callback;
- (void)refreshAccessToken:(AccessTokenResultCompletionFuncCallback _Nonnull ) callback;
- (NSString * _Nullable)getJwtToken;
- (NSDate * _Nullable)getGuestIssuerAccessTokenExpiration;
- (NSDate * _Nullable)getGuestIssuerJwtExpiration;
- (void)addLoginTelemetry:(enum CHTelemetry)loginEvent startTime:(NSDate * _Nonnull)startTime endTime:(NSDate * _Nonnull)endTime;
- (void)isNetworkReachable:(BOOL) isNetworkReachable;
- (void)setUCDomainServerUrl:(NSString * _Nonnull)ucDomain serverUrl:(NSString * _Nonnull)serverUrl;
- (void)retryUCSSOLogin;
- (void)forceRegisterPhoneServices;
- (void)setCUCMCredential:(NSString * _Nonnull)username password:(NSString * _Nonnull)password;
- (void)processSSOBrowserNavigationResult:(enum CHUCBrowserLoginSSONavResult)result currentUrl:(NSString * _Nonnull)currentUrl document:(NSString * _Nonnull)document;
- (void)ucCancelSSOLogin;
- (void)startUCServices;
- (bool)isUCLoggedIn;
- (CHUCLoginServerConnectionStatus)getUCServerConnectionStatus;
- (void)getSearchResult:(NSString * _Nonnull)searchString callback:(_Nonnull ListSpacesCompletionFuncCallback) callback;
- (NSArray<CHCallHistoryRecord *> * _Nonnull)getCallHistory;

// MARK: Calling
- (void)dial:(NSString * _Nonnull)input password:(NSString * _Nonnull)password captchaId:(NSString * _Nonnull)captchaId captchaVerifyCode:(NSString * _Nonnull)captchaVerifyCode callback:(_Nonnull CallCreatedCompletionCallback) callback;
- (void)refreshMeetingCaptcha:(_Nonnull CaptchaRefreshCompletionCallback)callback;
- (void)startShare:(NSString * _Nonnull)callId;
- (void)stopShare:(NSString * _Nonnull)callId;
- (void)setupExternalInput:(NSString * _Nonnull)callId height:(NSNumber * _Nonnull)height width:(NSNumber * _Nonnull)width;
- (void)sendFrameToExternalInputter:(NSString * _Nonnull)callId timeStamp:(NSNumber * _Nonnull)timeStamp height:(NSNumber * _Nonnull)height width:(NSNumber * _Nonnull)width data:(void * const _Nonnull)data length:(NSNumber * _Nonnull)length;
- (void)answer:(NSString * _Nonnull)callId isModerator:(bool)isModerator pin:(NSString * _Nonnull)pin localVideoView:(void * _Nullable)localVideoView remoteVideoView:(void * _Nullable)remoteVideoView sharingVideoView:(void * _Nullable)sharingVideoView callback:(_Nullable CallStartedCompletionCallback) callback;
- (NSArray<CHMeetingInfo *> * _Nullable)getSchedules:(NSString * _Nonnull)callId;
- (void)joinCall:(NSString * _Nonnull)callId isModerator:(bool)isModerator pin:(NSString * _Nonnull)pin isAudioOnly:(bool)isAudioOnly localVideoView:(void * _Nullable)localVideoView remoteVideoView:(void * _Nullable)remoteVideoView sharingVideoView:(void * _Nullable)sharingVideoView callback:(_Nullable CallStartedCompletionCallback) callback;
- (void)declineCall:(NSString * _Nonnull)callId;
- (void)endCall:(NSString * _Nonnull)callId;
- (void)endActiveCall;
- (void)muteAudio:(NSString * _Nonnull)callId participantId:(NSString * _Nonnull)participantId isMuted:(bool)isMuted;
- (void)muteAll:(NSString * _Nonnull)callId doMute:(bool)doMute;
- (bool)isOnHold:(NSString * _Nonnull)callId;
- (void)holdCall:(NSString * _Nonnull)callId isMuted:(bool)onHold;
- (void)startAssociatedCall:(NSString * _Nonnull)callId dialNumber:(NSString * _Nonnull)dialNumber associationType:(enum CHCallAssociationType)associationType audioCall:(bool)audioCall callback:(_Nullable CallStartedCompletionCallback) callback;
- (void)transferCall:(NSString * _Nonnull)fromCallId toCallId:(NSString * _Nonnull)toCallId;
- (void)mergeCall:(NSString * _Nonnull)callId targetCallId:(NSString * _Nonnull)targetCallId;
- (void)swapCamera:(NSString * _Nonnull)callId;
- (void)restartAudioSession:(NSString * _Nonnull)callId;
- (void)restartMediaSession:(NSString * _Nonnull)callId;
- (NSArray<CHCallMembership *> * _Nonnull)getCallMemberships:(NSString * _Nonnull)callId;
- (NSString * _Nonnull)getCallIdByNotificationId:(NSString * _Nonnull)notificationId notificationType:(enum CHNotificationCallType)notificationType;
- (CHCall * _Nullable)getCall:(NSString * _Nonnull)callId;
- (void)setVideoMaxTxFPS:(NSNumber * _Nonnull)fps;
- (void)setVideoEnableDecoderMosaic:(bool)value;
- (NSString * _Nonnull)getWmeVersion;
- (void)letIn:(NSString * _Nonnull)callId participantIds:(NSArray<NSString *> * _Nonnull) participantIds callback:(LetInCompletionCallback _Nonnull)callback;
- (void)sendFeedback:(NSNumber * _Nonnull)rating comments:(NSString * _Nonnull) comments;
- (NSString * _Nonnull)sendDTMF:(NSString * _Nonnull)callId keys:(NSString * _Nonnull) keys;
- (void)enableBNR:(NSString * _Nonnull)callId enable:(bool)enable;
- (bool)isBNREnabled:(NSString * _Nonnull)callId;
- (bool)setBNRProfileMode:(NSString * _Nonnull)callId mode:(NSNumber * _Nonnull)mode;
- (NSNumber * _Nonnull)getBNRProfileMode:(NSString * _Nonnull)callId;
- (void)setVideoMaxRxBandwidth:(NSNumber * _Nonnull)bandwidth;
- (void)setVideoMaxTxBandwidth:(NSNumber * _Nonnull)bandwidth;
- (void)setSharingMaxRxBandwidth:(NSNumber * _Nonnull)bandwidth;
- (void)setAudioMaxRxBandwidth:(NSNumber * _Nonnull)bandwidth;
- (bool)cameraFocusAtPoint:(NSString * _Nonnull)callId pointX:(NSNumber * _Nonnull)pointX pointY:(NSNumber * _Nonnull)pointY;
- (bool)setCameraFlashMode:(NSString * _Nonnull)callId mode:(enum CHVideoFlashMode)mode;
- (enum CHVideoFlashMode)getCameraFlashMode:(NSString * _Nonnull)callId;
- (enum CHVideoTorchMode)getCameraTorchMode:(NSString * _Nonnull)callId;
- (bool)setCameraTorchMode:(NSString * _Nonnull)callId mode:(enum CHVideoTorchMode)mode;
- (CHCameraExposureDuration * _Nonnull)getCameraExposureDuration:(NSString * _Nonnull)callId;
- (CHCameraExposureISO * _Nonnull)getCameraExposureISO:(NSString * _Nonnull)callId;
- (CHCameraExposureTargetBias * _Nonnull)getCameraExposureTargetBias:(NSString * _Nonnull)callId;
- (bool)setCameraCustomExposure:(NSString * _Nonnull)callId duration:(NSNumber * _Nonnull)duration iso:(NSNumber * _Nonnull)iso;
- (bool)setCameraAutoExposure:(NSString * _Nonnull)callId targetBias:(NSNumber * _Nonnull)targetBias;
- (bool)setVideoZoomFactor:(NSString * _Nonnull)callId factor:(NSNumber * _Nonnull)factor;
- (NSNumber * _Nonnull)getVideoZoomFactor:(NSString * _Nonnull)callId;
- (bool)takePhoto:(NSString * _Nonnull)callId;
- (void)startPreview:(void * _Nonnull)viewHandle;
- (void)stopPreview;
- (void)setVideoStreamMode:(enum CHVideoStreamMode)mode;
- (enum CHVideoStreamMode)getVideoStreamMode;
- (void)setCompositedVideoLayout:(NSString * _Nonnull)callId layout:(enum CHCompositedVideoLayout)layout;
- (void)setCompositedVideoLayout:(NSString * _Nonnull)callId layout:(enum CHCompositedVideoLayout)layout callback:(CompositedVideoLayoutCompletionCallback _Nonnull)callback;
- (enum CHCompositedVideoLayout)getCompositedVideoLayout:(NSString * _Nonnull)callId;
- (void)addAuxVideoView:(NSString * _Nonnull)callId type:(enum CHMediaStreamType)type auxView:(void * _Nullable)auxView;
- (void)removeAuxVideoView:(NSString * _Nonnull)callId type:(enum CHMediaStreamType)type auxView:(void * _Nullable)auxView;
- (void)setDefaultCameraMode:(NSNumber * _Nonnull)mode;
- (void)setVideoRenderViews:(NSString * _Nonnull)callId localVideoView:(void * _Nullable)localVideoView remoteVideoView:(void * _Nullable)remoteVideoView;
- (void)setSharingRenderView:(NSString * _Nonnull)callId sharingVideoView:(void * _Nullable)sharingVideoView;
- (void)setRemoteVideoRenderMode:(NSString * _Nonnull)callId mode:(CHVideoRenderMode)mode;
- (void)onScheduleChanged:(NSString * _Nonnull)callId callback:(_Nonnull CallScheduleChangedCompletionCallback) callback;
- (void)setIncomingCallListener:(_Nonnull IncomingCompletionCallback) callback;
- (void)setDeviceChangedListener:(NSString * _Nonnull)callId callback:(_Nonnull DeviceChangedCompletionCallback) callback;
- (void)setSendingVideo:(NSString * _Nonnull)callId sending:(bool) sending;
- (void)setSendingAudio:(NSString * _Nonnull)callId sending:(bool) sending;
- (void)setSendingSharing:(NSString * _Nonnull)callId sending:(bool) sending sourceId:(NSString * _Nonnull)sourceId;
- (void)setReceivingVideo:(NSString * _Nonnull)callId receiving:(bool) receiving;
- (void)setReceivingAudio:(NSString * _Nonnull)callId receiving:(bool) receiving;
- (void)setReceivingSharing:(NSString * _Nonnull)callId receiving:(bool) receiving;
- (void)setOnCallRingingChangedListener:(NSString * _Nonnull)callId callback:(_Nonnull CallRingingChangedCompletionCallback) callback;
- (void)setOnCallConnectedListener:(NSString * _Nonnull)callId callback:(_Nonnull CallConnectedCompletionCallback) callback;
- (void)setOnCallDisconnectedListener:(NSString * _Nonnull)callId callback:(_Nonnull CallDisconnectedCompletionCallback) callback;
- (void)setOnCallTerminatedListener:(NSString * _Nonnull)callId callback:(_Nonnull CallTerminatedCompletionCallback) callback;
- (void)setOnCallFailedListener:(NSString * _Nonnull)callId callback:(_Nonnull CallFailedCompletionCallback) callback;
- (void)setOnCallInfoChangedListener:(NSString * _Nonnull)callId callback:(_Nonnull CallInfoChangedCompletionCallback) callback;
- (bool)isVirtualBackgroundSupported;
- (void)fetchVirtualBackgroundItems:(FetchVirtualBackgroundCompletionCallback _Nonnull) callback;
- (void)uploadVirtualBackground:(NSDictionary<CHLocalFile *,NSArray<NSData *> *>* _Nonnull)backgroundImage callback:(UploadVirtualBackgroundCompletionCallback _Nonnull) callback;
- (void)deleteVirtualBackgroundItem:(CHVirtualBackgroundItem* _Nonnull)item callback:(DeleteVirtualBackgroundCompletionCallback _Nonnull) callback;
- (void)setVirtualBackgroundForPreview:(CHVirtualBackgroundItem* _Nonnull)item callback:(PreviewVirtualBackgroundCompletionCallback _Nonnull) callback;
- (void)setVirtualBackgroundForCall:(CHVirtualBackgroundItem* _Nonnull)item callback:(_Nonnull ApplyVirtualBackgroundCompletionCallback) callback;
- (void)setOnPerformanceCausedResolutionChangedListener:(NSString * _Nonnull)callId callback:(_Nonnull CallOnHitCpuThresholdCompletionCallback) callback;
- (void)setVirtualBackgroundLimit:(NSNumber* _Nonnull)limit;
- (NSNumber * _Nonnull)getVirtualBackgroundLimit;
- (void)forceSendingVideoLandscape:(NSString * _Nonnull)callId forceLandscape:(bool)forceLandscape callback:(_Nonnull VideoForceLandscapeCompletionCallback)callback;
- (void)setOnCallPhotoOutputListener:(NSString * _Nonnull)callId callback:(_Nonnull CallPhotoOutputCompletionCallback) callback;

// MARK: Transcriptions
- (void)setOnTranscriptionArrivedListener:(NSString * _Nonnull)callId callback:(_Nonnull CallTranscriptionArrivedCompletionCallback) callback;
- (void)setWXAEnabled:(NSString * _Nonnull)callId isEnabled:(bool) isEnabled callback:(SingleBoolCompletionFuncCallback _Nonnull ) callback;

// MARK: CalendarMeetings
- (void)listCalendarMeetings:(NSDate * _Nullable)fromDate toDate:(NSDate * _Nullable)toDate callback:(_Nonnull ListCalendarMeetingsCompletionCallback)callback;
- (void)getCalendarMeeting:(NSString * _Nonnull)meetingId callback:(_Nonnull GetCalendarMeetingCompletionCallback)callback;
- (void)setOnCalendarMeetingEventListener:(_Nonnull  CalendarMeetingEventCompletionCallback)callback;

// MARK: Persons
- (void)getMe:(PersonGetResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)getPersonWithId:(NSString * _Nonnull)personId completionHandler:(PersonGetResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)listPersons:(NSString * _Nullable)email displayName:(NSString * _Nullable)displayName idString:(NSString* _Nullable)idString orgId:(NSString* _Nullable)orgId max:(NSNumber * _Nullable)max completionHandler:(ListPersonsCompletionFuncCallback _Nonnull)completionHandler;
- (void)createPerson:(NSString * _Nonnull)email displayName:(NSString * _Nullable)displayName firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName avatar:(NSString * _Nullable)avatar orgId:(NSString* _Nullable)orgId roles:(NSArray<NSNumber *> * _Nonnull)roles licenses:(NSArray<NSString *> * _Nonnull)licenses siteUrls:(NSArray<NSString *> * _Nonnull)siteUrls completionHandler:(CreatePersonCompletionFuncCallback _Nonnull)completionHandler;
- (void)updatePerson:(NSString * _Nonnull)personId email:(NSString * _Nullable)email displayName:(NSString * _Nullable)displayName firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName avatar:(NSString * _Nullable)avatar orgId:(NSString* _Nullable)orgId roles:(NSArray<NSNumber *> * _Nonnull)roles licenses:(NSArray<NSString *> * _Nonnull)licenses siteUrls:(NSArray<NSString *> * _Nonnull)siteUrls completionHandler:(UpdatePersonCompletionFuncCallback _Nonnull)completionHandler;
- (void)deletePerson:(NSString * _Nonnull)personId completionHandler:(DeletePersonCompletionFuncCallback _Nonnull)completionHandler;

// MARK: Teams
- (void)listTeams:(NSNumber * _Nonnull)maxTeams completionHandler:(TeamListResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)createTeam:(NSString * _Nonnull)name completionHandler:(TeamCreateResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)getTeamWithId:(NSString * _Nonnull)teamId completionHandler:(TeamGetResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)updateTeamWith:(NSString * _Nonnull)teamId newName:(NSString * _Nonnull)newName completionHandler:(TeamUpdateResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)deleteTeamWithId:(NSString * _Nonnull)teamId completionHandler:(_Nonnull TeamArchiveResultCompletionFuncCallback)completionHandler;

// MARK: Spaces
- (void)listSpaces:(NSString * _Nullable)teamId max:(NSNumber * _Nullable)max conversationType:(enum CHConversationType)conversationType sortType:(enum CHConversationSortType)sortType completionHandler:(ListSpacesCompletionFuncCallback _Nonnull)completionHandler;
- (void)getSpace:(NSString * _Nonnull)spaceId completionHandler:(SingleSpaceCompletionFuncCallback _Nonnull)completionHandler;
- (void)createSpace:(NSString * _Nullable)teamId title:(NSString * _Nonnull)title completionHandler:(SingleSpaceCompletionFuncCallback _Nonnull)completionHandler;
- (void)updateSpaceTitle:(NSString * _Nonnull)spaceId newTitle:(NSString * _Nonnull)newTitle completionHandler:(UpdateSpaceTitleResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)deleteSpace:(NSString * _Nonnull)spaceId  completionHandler:(DeleteSpaceCompletionFuncCallback _Nonnull)completionHandler;
- (void)getMeetingInfoFor:(NSString * _Nonnull)spaceId completionHandler:(void (^ _Nonnull)(CHSpaceMeetingInfo * _Nullable meetingInfo, BOOL success))completionHandler;
- (void)getReadStatus:(NSString * _Nonnull)spaceId completionHandler:(SingleSpaceReadStatusCompletionFuncCallback _Nonnull)completionHandler;
- (void)listReadStatus:(NSNumber * _Nonnull)max completionHandler:(ListSpaceReadStatusCompletionFuncCallback _Nonnull)completionHandler;
- (void)setOnSpaceEventListener:(_Nullable SpaceEventCompletionCallback) callback;
- (void)setOnSpaceEventWithPayloadListener:(_Nullable SpaceEventWithPayloadCompletionCallback) callback;
- (void)listWithActiveCalls:(ListSpacesActiveCallsCompletionCallback _Nonnull)completionHandler;

// MARK: Team Membership
- (void)listTeamMembershipIn:(NSString * _Nonnull)teamId max:(NSNumber * _Nullable)max completionHandler:(ListTeamMembershipCompletionFuncCallback _Nonnull)completionHandler;
- (void)createTeamMembershipWithPersonId:(NSString * _Nonnull)personId teamId:(NSString * _Nonnull)teamId isModerator:(bool)isModerator completionHandler:(CreateTeamMembershipCompletionFuncCallback _Nonnull)completionHandler;
- (void)createTeamMembershipWithEmailAddress:(NSString * _Nonnull)emailAddress teamId:(NSString * _Nonnull)teamId isModerator:(bool)isModerator completionHandler:(CreateTeamMembershipCompletionFuncCallback _Nonnull)completionHandler;
- (void)getTeamMembership:(NSString * _Nonnull)teamMembershipId completionHandler:(GetTeamMembershipCompletionFuncCallback _Nonnull)completionHandler;
- (void)updateTeamMembershipWith:(NSString * _Nonnull)teamMembershipId isModerator:(bool)isModerator completionHandler:(UpdateTeamMembershipCompletionFuncCallback _Nonnull)completionHandler;
- (void)deleteTeamMembershipWithId:(NSString * _Nonnull)teamMembershipId completionHandler:(DeleteTeamMembershipCompletionFuncCallback _Nonnull)completionHandler;

// MARK: Space Membership
- (void)listMemberships:(NSString * _Nullable)spaceId personId:(NSString * _Nullable)personId email:(NSString * _Nullable)email max:(NSNumber * _Nullable)max completionHandler:(ListMembershipsCompletionFuncCallback _Nonnull)completionHandler;
- (void)getMembership:(NSString * _Nonnull)membershipId completionHandler:(GetMembershipByMembershipIdCompletionFuncCallback _Nonnull)completionHandler;
- (void)updateMembershipWith:(NSString * _Nonnull)membershipId isModerator:(bool)isModerator completionHandler:(MembershipUpdateResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)createMembershipWithPersonId:(NSString * _Nonnull)personId spaceId:(NSString * _Nonnull)spaceId isModerator:(bool)isModerator completionHandler:(CreateMembershipCompletionFuncCallback _Nonnull)completionHandler;
- (void)createMembershipWithEmailAddress:(NSString * _Nonnull)emailAddress spaceId:(NSString * _Nonnull)spaceId isModerator:(bool)isModerator completionHandler:(CreateMembershipCompletionFuncCallback _Nonnull)completionHandler;
- (void)deleteMembershipWithId:(NSString * _Nonnull)membershipId completionHandler:(MembershipDeleteResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)listMembershipsWithReadStatus:(NSString * _Nonnull)spaceId completionHandler:(ListMembershipsReadStatusCompletionFuncCallback _Nonnull)completionHandler;
- (void)setOnMembershipEventListener:(_Nullable MembershipEventCompletionCallback) callback;
- (void)setOnMembershipEventWithPayloadListener:(_Nullable MembershipEventWithPayloadCompletionCallback) callback;

// MARK: Messages
- (void)listMessages:(NSString * _Nonnull)spaceId max:(NSNumber * _Nonnull)max beforeMessageId:(NSString * _Nullable)beforeMessageId beforeDate:(NSDate * _Nullable)beforeDate mentionedPeople:(NSArray<CHMention *>* _Nullable)mentionedPeople completionHandler:(ListMessagesCompletionFuncCallback _Nonnull)completionHandler;
- (void)markMessageRead:(NSString * _Nonnull)spaceId messageId:(NSString * _Nullable)messageId completionHandler:(MarkMessageResultCompletionFuncCallback _Nonnull)completionHandler;
- (void)getMessage:(NSString * _Nonnull)messageId completionHandler:(_Nonnull SingleMessageCompletionFuncCallback)completionHandler;
- (void)deleteMessage:(NSString * _Nonnull)messageId completionHandler:(_Nonnull MessageDeleteResultCompletionFuncCallback)completionHandler;
- (void)downloadFile:(NSString * _Nonnull)spaceId messageId:(NSString * _Nonnull)messageId contentIndex:(NSNumber * _Nonnull)contentIndex downloadPath:(NSString * _Nonnull)downloadPath progressHandler:(_Nullable MessageDownloadFileProgressCompletionFuncCallback)progressHandler completionHandler:(_Nonnull MessageDownloadFileCompletionFuncCallback)completionHandler;
- (void)postMessage:(CHMessageText * _Nullable)messageText destination:(NSString * _Nonnull)destination parent:(NSString * _Nullable)parent mentions:(NSArray<CHMention *>* _Nonnull)mentions files:(NSArray<NSDictionary<CHLocalFile *,NSArray<NSData *> *>*>* _Nonnull)files completionHandler:(_Nonnull MessagePostCompletionFuncCallback)completionHandler;
- (void)editMessage:(CHMessageText * _Nullable)messageText spaceId:(NSString * _Nonnull)spaceId parent:(NSString * _Nonnull)parent mentions:(NSArray<CHMention *>* _Nonnull)mentions completionHandler:(_Nonnull MessagePostCompletionFuncCallback)completionHandler;
- (void)downloadThumbnail:(NSString * _Nonnull)spaceId messageId:(NSString * _Nonnull)messageId contentIndex:(NSNumber * _Nonnull)contentIndex completionHandler:(_Nonnull MessageThumbnailResultCompletionFuncCallback)completionHandler;
- (void)setOnMessageEventListener:(_Nullable MessageEventCompletionCallback) callback;
- (void)setOnMessageEventWithPayloadListener:(_Nullable MessageEventWithPayloadCompletionCallback) callback;


// MARK: Webhooks
- (void)listWebhooksWithMax:(NSNumber * _Nullable)max completionHandler:(ListWebhooksCompletionFuncCallback _Nonnull)completionHandler;
- (void)getWebhook:(NSString * _Nonnull)webhookId completionHandler:(GetWebhookCompletionFuncCallback _Nonnull)completionHandler;
- (void)createWebhook:(NSString * _Nonnull)name targetUrl:(NSString * _Nonnull)targetUrl resource:(NSString * _Nonnull)resource event:(NSString * _Nonnull)event filter:(NSString * _Nullable)filter secret:(NSString * _Nullable)secret  completionHandler:(CreateWebhookCompletionFuncCallback _Nonnull)completionHandler;
- (void)updateWebhook:(NSString * _Nonnull)webhookId name:(NSString * _Nonnull)name targetUrl:(NSString * _Nonnull)targetUrl secret:(NSString * _Nullable)secret status:(NSString * _Nullable)status completionHandler:(UpdateWebhookCompletionFuncCallback _Nonnull)completionHandler;
- (void)deleteWebhook:(NSString * _Nonnull)webhookId completionHandler:(DeleteWebhookCompletionFuncCallback _Nonnull)completionHandler;

- (NSString * _Nonnull) getServiceUrl:(enum CHServiceUrlType)serviceUrlType;
- (NSString * _Nullable) pathTologFilesAsZip;
- (void)base64EncodeResource:(enum CHResourceType)resourceType resource:(NSString * _Nonnull)resource completionHandler:(Base64EncodeCompletionFuncCallback _Nonnull)completionHandler;
- (CHResource * _Nonnull)base64DecodeResource:(NSString * _Nonnull)encodedResource;
- (void)setOnMediaQualityInfoChangedListener:(NSString * _Nonnull)callId callback:(_Nonnull MediaQualityInfoChangedCallback)callback;

- (void)setOnMediaStreamAvailabilityListener:(NSString * _Nonnull)callId callback:(_Nonnull MediaStreamAvailabilityCallback)callback;
- (void)setOnMediaStreamChangeEventListener:(NSString * _Nonnull)callId callback:(_Nonnull MediaStreamChangeEventCallback)callback;

- (void)setMediaStreamCategoryA:(NSString * _Nonnull)callId duplicate:(bool)duplicate quality:(enum CHMediaStreamQuality)quality bitrate:(int)bitrate;
- (void)setMediaStreamsCategoryB:(NSString * _Nonnull)callId numStreams:(int)numStreams quality:(enum CHMediaStreamQuality)quality bitrate:(int)bitrate;
- (void)setMediaStreamCategoryC:(NSString * _Nonnull)callId participantId:(NSString * _Nonnull)participantId quality:(enum CHMediaStreamQuality)quality bitrate:(int)bitrate;
- (void)removeMediaStreamCategoryA:(NSString * _Nonnull)callId;
- (void)removeMediaStreamsCategoryB:(NSString * _Nonnull)callId;
- (void)removeMediaStreamCategoryC:(NSString * _Nonnull)callId participantId:(NSString * _Nonnull)participantId;

// MARK: Breakout Session
- (void)joinBreakoutSession:(NSString * _Nonnull)callId breakoutSession:(CHBreakoutSession* _Nonnull)breakoutSession;
- (void)returnToMainSession:(NSString * _Nonnull)callId;

// MARK: BreakoutSession Listener
- (void)setSessionEnabledListener:(NSString * _Nonnull)callId callback:(_Nonnull SessionEnabledCallback)callback;
- (void)setSessionStartedListener:(NSString * _Nonnull)callId callback:(_Nonnull SessionStartedCallback)callback;
- (void)setBreakoutUpdatedListener:(NSString * _Nonnull)callId callback:(_Nonnull BreakoutUpdatedCallback)callback;
- (void)setSessionJoinedListener:(NSString * _Nonnull)callId callback:(_Nonnull SessionJoinedCallback)callback;
- (void)setJoinedSessionUpdatedListener:(NSString * _Nonnull)callId callback:(_Nonnull JoinedSessionUpdatedCallback)callback;
- (void)setSessionJoinableListChangedListener:(NSString * _Nonnull)callId callback:(_Nonnull SessionJoinableListChangedCallback)callback;
- (void)setHostAskingReturnToMainSessionListener:(NSString * _Nonnull)callId callback:(_Nonnull HostAskingReturnToMainSessionCallback)callback;
- (void)setBroadcastMessageReceivedListener:(NSString * _Nonnull)callId callback:(_Nonnull BroadcastMessageReceivedCallback)callback;
- (void)setSessionClosingListener:(NSString * _Nonnull)callId callback:(_Nonnull SessionClosingCallback)callback;
- (void)setReturnedToMainSessionListener:(NSString * _Nonnull)callId callback:(_Nonnull SessionEndedCallback)callback;
- (void)setOnBreakoutErrorListener:(NSString * _Nonnull)callId callback:(_Nonnull BreakoutErrorCallback)callback;

// MARK: Restricted Network API's
- (bool)isRestrictedNetwork;
- (void)setOnRestrictedNetworkStatusChangeListener:(_Nonnull RestrictedNetworkStatusChangeCallback)callback;
@end
#endif
