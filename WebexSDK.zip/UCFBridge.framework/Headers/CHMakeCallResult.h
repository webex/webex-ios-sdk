// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHMakeCallResult_IMPORTED
#define CHMakeCallResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHMakeCallResult) {
    CHMakeCallResultPasswordRequired,
    CHMakeCallResultInvalidPassword,
    CHMakeCallResultCaptchaRequired,
    CHMakeCallResultInvalidPasswordWithCaptcha,
    CHMakeCallResultNoError,
    CHMakeCallResultInternalError
};

#endif

