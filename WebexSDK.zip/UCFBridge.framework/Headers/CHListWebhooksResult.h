// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHListWebhooksResult_IMPORTED
#define CHListWebhooksResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHListWebhooksResult) {
    CHListWebhooksResultNoError,
    CHListWebhooksResultInternalError,
    CHListWebhooksResultBadRequest
};

#endif

