// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHInviteeResponse_IMPORTED
#define CHInviteeResponse_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHInviteeResponse) {
    CHInviteeResponseOrganizer,
    CHInviteeResponseAccepted,
    CHInviteeResponseDeclined,
    CHInviteeResponseTentative,
    CHInviteeResponseUnavailable,
    CHInviteeResponseWaitingForResponse
};

#endif

