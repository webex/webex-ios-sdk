// DO NOT EDIT - Auto generated
// Generated with objc_enum.j2

#pragma once
#ifndef CHDeleteTeamMembershipResult_IMPORTED
#define CHDeleteTeamMembershipResult_IMPORTED

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, CHDeleteTeamMembershipResult) {
    CHDeleteTeamMembershipResultNoError,
    CHDeleteTeamMembershipResultInternalError,
    CHDeleteTeamMembershipResultInvalidTeamMembershipId,
    CHDeleteTeamMembershipResultTeamNotFound,
    CHDeleteTeamMembershipResultSpaceTypeDirect,
    CHDeleteTeamMembershipResultNoPeople,
    CHDeleteTeamMembershipResultLoadingError,
    CHDeleteTeamMembershipResultSelfNotInTeam,
    CHDeleteTeamMembershipResultInsufficientTeamPrivileges
};

#endif

